package midproject.utilities;

import midproject.shared.Room;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import midproject.shared.Account;
import midproject.shared.Booking;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class JSONUtility {
    public static void saveAccountJSON(List<Account> accountList){
        JSONArray accounts = new JSONArray();
        for (Account acc: accountList) {
            JSONObject account = new JSONObject();
            account.put("accountNumber", acc.getAccountNumber());
            account.put("firstName", acc.getFirstName());
            account.put("lastName", acc.getLastName());
            account.put("age", acc.getAge());
            account.put("phoneNumber", acc.getPhoneNumber());
            account.put("email", acc.getEmail());
            account.put("password", acc.getPassword());
            account.put("isAdmin", acc.isAdmin());
            account.put("isBanned", acc.isBanned());
            account.put("isOnline", acc.isOnline());
            account.put("uniqueID", acc.getUUID());

            JSONObject accountObject = new JSONObject();
            accountObject.put("account", account);
            accounts.add(accountObject);
        }

        //Write JSON file
        try (FileWriter file = new FileWriter("res/registration.json")) {
            //We can write any JSONArray or JSONObject instance to the file
            file.write(accounts.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveBookingJSON(List<Booking> bookingList){
        JSONArray appointments = new JSONArray();
        for (Booking book: bookingList) {
            JSONObject appointment = new JSONObject();
            appointment.put("bookingID", book.getBookingID());
            appointment.put("firstName", book.getFirstName());
            appointment.put("lastName", book.getLastName());
            appointment.put("phoneNumber", book.getPhoneNumber());
            appointment.put("email", book.getEmailAddress());
            appointment.put("checkInDate", book.getCheck_in_date());
            appointment.put("checkOutDate", book.getCheck_out_date());
            appointment.put("roomType", book.getRoomType());
            appointment.put("roomCapacity", book.getRoomCapacity());
            appointment.put("uniqueID", book.getUniqueID());
            appointment.put("daysStayed", book.getDaysStayed());
            appointment.put("status", book.getStatus());

            JSONObject appointmentObject = new JSONObject();
            appointmentObject.put("appointment", appointment);
            appointments.add(appointmentObject);
        }

        //Write JSON file
        try (FileWriter file = new FileWriter("res/appointments.json")) {
            //We can write any JSONArray or JSONObject instance to the file
            file.write(appointments.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveGuestJSON(List<Booking> guestList){
        JSONArray guests = new JSONArray();
        for (Booking book: guestList) {
            JSONObject guest = new JSONObject();
            guest.put("bookingID", book.getBookingID());
            guest.put("firstName", book.getFirstName());
            guest.put("lastName", book.getLastName());
            guest.put("phoneNumber", book.getPhoneNumber());
            guest.put("email", book.getEmailAddress());
            guest.put("checkInDate", book.getCheck_in_date());
            guest.put("checkOutDate", book.getCheck_out_date());
            guest.put("roomType", book.getRoomType());
            guest.put("roomCapacity", book.getRoomCapacity());
            guest.put("uniqueID", book.getUniqueID());

            JSONObject guestObject = new JSONObject();
            guestObject.put("guest", guest);
            guests.add(guestObject);
        }

        //Write JSON file
        try (FileWriter file = new FileWriter("res/guests.json")) {
            //We can write any JSONArray or JSONObject instance to the file
            file.write(guests.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveCheckOutJSON(List<Booking> checkoutList){
        JSONArray checkouts = new JSONArray();
        for (Booking book: checkoutList) {
            JSONObject checkout = new JSONObject();
            checkout.put("bookingID", book.getBookingID());
            checkout.put("firstName", book.getFirstName());
            checkout.put("lastName", book.getLastName());
            checkout.put("phoneNumber", book.getPhoneNumber());
            checkout.put("email", book.getEmailAddress());
            checkout.put("checkInDate", book.getCheck_in_date());
            checkout.put("checkOutDate", book.getCheck_out_date());
            checkout.put("roomType", book.getRoomType());
            checkout.put("roomCapacity", book.getRoomCapacity());
            checkout.put("uniqueID", book.getUniqueID());
            checkout.put("daysStayed", book.getDaysStayed());

            JSONObject checkoutObject = new JSONObject();
            checkoutObject.put("checkout", checkout);
            checkouts.add(checkoutObject);
        }

        //Write JSON file
        try (FileWriter file = new FileWriter("res/checkedOut.json")) {
            //We can write any JSONArray or JSONObject instance to the file
            file.write(checkouts.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveRoomsJSON(List<Room> roomsList){
        JSONArray rooms = new JSONArray();
        for (Room room: roomsList) {
            JSONObject saveRoom = new JSONObject();
            saveRoom.put("roomID", String.valueOf(room.getRoomID()));
            saveRoom.put("roomType", room.getRoomType());
            saveRoom.put("roomCapacity", String.valueOf(room.getRoomCapacity()));
            saveRoom.put("active", room.getActive());
            saveRoom.put("imgSrc", room.getImgSrc());

            JSONArray bookedDates = new JSONArray();
            for (Object[] dates : room.getBookedDates()){
                JSONObject saveDateB = new JSONObject();
                saveDateB.put("start", dates[0]);
                saveDateB.put("end", dates[1]);

                JSONObject dateObjectB = new JSONObject();
                dateObjectB.put("date", saveDateB);
                bookedDates.add(dateObjectB);
            }
            saveRoom.put("bookedDates", bookedDates);

            JSONArray disabledDates = new JSONArray();
            for (Object[] dates : room.getDisabledDates()){
                JSONObject saveDateD = new JSONObject();
                saveDateD.put("start", dates[0]);
                saveDateD.put("end", dates[1]);

                JSONObject dateObjectD = new JSONObject();
                dateObjectD.put("date", saveDateD);
                disabledDates.add(dateObjectD);
            }
            saveRoom.put("disabledDates", disabledDates);

            JSONObject roomObject = new JSONObject();
            roomObject.put("room", saveRoom);
            rooms.add(roomObject);
        }

        //Write JSON file
        try (FileWriter file = new FileWriter("res/rooms.json")) {
            //We can write any JSONArray or JSONObject instance to the file
            file.write(rooms.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Account> readAccountJSON(){
        List<Account> accountList = new ArrayList<>();
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader("res/registration.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONArray accounts = (JSONArray) obj;

            //Iterate over employee array
            accounts.forEach(account -> {
                Account acc = parseAccountObject((JSONObject) account);
                accountList.add(acc);
            });

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return accountList;
    }

    private static Account parseAccountObject(JSONObject acc){
        //Get account object within list
        JSONObject accountObject = (JSONObject) acc.get("account");
        String accNum = (String) accountObject.get("accountNumber");
        String firstName = (String) accountObject.get("firstName");
        String lastName = (String) accountObject.get("lastName");
        String age = (String) accountObject.get("age");
        String phoneNum = (String) accountObject.get("phoneNumber");
        String email = (String) accountObject.get("email");
        String password = (String) accountObject.get("password");
        boolean isAdmin = (boolean) accountObject.get("isAdmin");
        boolean isBanned = (boolean) accountObject.get("isBanned");
        boolean isOnline = (boolean) accountObject.get("isOnline");
        String uniqueID = (String) accountObject.get("UUID");
        return new Account(accNum, firstName, lastName, age, phoneNum, email, password, isAdmin, isBanned, isOnline, uniqueID);
    }

    public static List<Booking> readBookingJSON(){
        List<Booking> bookingList = new ArrayList<>();
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader("res/appointments.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONArray appointments = (JSONArray) obj;

            //Iterate over employee array
            appointments.forEach(appointment -> {
                Booking booking = parseAppointmentObject((JSONObject) appointment);
                bookingList.add(booking);
            });

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return bookingList;
    }

    private static Booking parseAppointmentObject(JSONObject appointment){
        //Get employee object within list
        JSONObject appointmentObject = (JSONObject) appointment.get("appointment");
        String bookingID = (String) appointmentObject.get("bookingID");
        String firstName = (String) appointmentObject.get("firstName");
        String lastName = (String) appointmentObject.get("lastName");
        String phoneNum = (String) appointmentObject.get("phoneNumber");
        String email = (String) appointmentObject.get("email");
        String checkInDate = (String) appointmentObject.get("checkInDate");
        String checkOutDate = (String) appointmentObject.get("checkOutDate");
        String roomType = (String) appointmentObject.get("roomType");
        String roomCapacity = (String) appointmentObject.get("roomCapacity");
        String uniqueID = (String) appointmentObject.get("UUID");
        String daysStayed = (String) appointmentObject.get("daysStayed");
        String status = (String) appointmentObject.get("status");
        return new Booking(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID, daysStayed, status);
    }

    public static List<Booking> readGuestJSON(){
        List<Booking> guestList = new ArrayList<>();
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader("res/guests.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONArray guests = (JSONArray) obj;

            //Iterate over employee array
            guests.forEach(guest -> {
                Booking checkIn = parseGuestObject((JSONObject) guest);
                guestList.add(checkIn);
            });

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return guestList;
    }

    private static Booking parseGuestObject(JSONObject appointment){
        //Get employee object within list
        JSONObject appointmentObject = (JSONObject) appointment.get("guest");
        String bookingID = (String) appointmentObject.get("bookingID");
        String firstName = (String) appointmentObject.get("firstName");
        String lastName = (String) appointmentObject.get("lastName");
        String phoneNum = (String) appointmentObject.get("phoneNumber");
        String email = (String) appointmentObject.get("email");
        String checkInDate = (String) appointmentObject.get("checkInDate");
        String checkOutDate = (String) appointmentObject.get("checkOutDate");
        String roomType = (String) appointmentObject.get("roomType");
        String roomCapacity = (String) appointmentObject.get("roomCapacity");
        String uniqueID = (String) appointmentObject.get("UUID");
        return new Booking(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID);
    }

    public static List<Booking> readCheckoutJSON(){
        List<Booking> checkOutList = new ArrayList<>();
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader("res/checkedOut.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONArray checkOuts = (JSONArray) obj;

            //Iterate over employee array
            checkOuts.forEach(guestOut -> {
                Booking checkOut = parseOutObject((JSONObject) guestOut);
                checkOutList.add(checkOut);
            });

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return checkOutList;
    }

    private static Booking parseOutObject(JSONObject appointment){
        //Get employee object within list
        JSONObject appointmentObject = (JSONObject) appointment.get("checkout");
        String bookingID = (String) appointmentObject.get("bookingID");
        String firstName = (String) appointmentObject.get("firstName");
        String lastName = (String) appointmentObject.get("lastName");
        String phoneNum = (String) appointmentObject.get("phoneNumber");
        String email = (String) appointmentObject.get("email");
        String checkInDate = (String) appointmentObject.get("checkInDate");
        String checkOutDate = (String) appointmentObject.get("checkOutDate");
        String roomType = (String) appointmentObject.get("roomType");
        String roomCapacity = (String) appointmentObject.get("roomCapacity");
        String uniqueID = (String) appointmentObject.get("UUID");
        String daysStayed = (String) appointmentObject.get("daysStayed");
        return new Booking(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID, daysStayed);
    }
    public static List<Room> readRoomsJSON(){
        List<Room> roomsList = new ArrayList<>();
        //JSON parser object to parse read file
        JSONParser jsonParser = new JSONParser();

        try (FileReader reader = new FileReader("res/rooms.json"))
        {
            //Read JSON file
            Object obj = jsonParser.parse(reader);

            JSONArray rooms = (JSONArray) obj;

            //Iterate over employee array
            rooms.forEach(room -> {
                Room newRoom = parseRoomObject((JSONObject) room);
                roomsList.add(newRoom);
            });

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return roomsList;
    }

    private static Room parseRoomObject(JSONObject room){
        //Get employee object within list
        JSONObject roomObject = (JSONObject) room.get("room");
        String roomID = (String) roomObject.get("roomID");
        String roomType = (String) roomObject.get("roomType");
        String roomCapacity = (String) roomObject.get("roomCapacity");
        boolean active = (boolean) roomObject.get("active");
        String imgSrc = (String) roomObject.get("imgSrc");
        List<Object[]> bookedDates = new ArrayList<>();
            JSONArray bdates = (JSONArray) roomObject.get("bookedDates");

            //Iterate over employee array
            bdates.forEach(date -> {
                Object[] newDate = parseDateBObject((JSONObject) date);
                bookedDates.add(newDate);
            });

        List<Object[]> disabledDates = new ArrayList<>();
            JSONArray ddates = (JSONArray) roomObject.get("disabledDates");

            //Iterate over employee array
            ddates.forEach(date -> {
                Object[] newDate = parseDateDBObject((JSONObject) date);
                disabledDates.add(newDate);
            });

        return new Room(Integer.parseInt(roomID), roomType, roomCapacity, active, imgSrc, bookedDates, disabledDates);
    }

    private static Object[] parseDateBObject(JSONObject date){
        //Get employee object within list
        JSONObject dateObject = (JSONObject) date.get("date");
        String start = (String) dateObject.get("start");
        String end = (String) dateObject.get("end");
        return new Object[]{start, end};
    }private static Object[] parseDateDBObject(JSONObject date){
        //Get employee object within list
        JSONObject dateObject = (JSONObject) date.get("date");
        String start = (String) dateObject.get("start");
        String end = (String) dateObject.get("end");
        return new Object[]{start, end};
    }
} // end of JSONUtility class 