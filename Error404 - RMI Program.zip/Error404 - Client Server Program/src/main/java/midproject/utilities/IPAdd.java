package midproject.utilities;

public class IPAdd {
    private static String serverIP;

    public static String getServerIP() {
        return serverIP;
    }

    public static void setServerIP(String ipAdd) {
        serverIP = ipAdd;
    }
} // end of IPAdd class 
