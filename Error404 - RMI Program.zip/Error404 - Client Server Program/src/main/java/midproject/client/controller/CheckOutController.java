package midproject.client.controller;

import midproject.client.view.CheckOutScreen;
import midproject.shared.Booking;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.List;

public class CheckOutController implements ActionListener{
    private final CheckOutScreen checkOutScreen;
    private final ApplicationController applicationController;

    public CheckOutController(CheckOutScreen checkOutScreen, ApplicationController applicationController) {
        this.checkOutScreen = checkOutScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        addListeners();
        populateTable();
        applicationController.switchScreen(checkOutScreen);
    }

    private void addListeners() {
        checkOutScreen.getSearchButton().addActionListener(this);
        checkOutScreen.addRefreshButtonListener(new RefreshButtonListener());
//        checkOutScreen.addCheckOutButtonListener(this);
//        checkOutScreen.addViewCheckOutButtonListener(this);
    } // end of addListeners
    private class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try{
                applicationController.requestUpdate("UPDATE_DATA");
                populateTable();
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == checkOutScreen.getSearchButton()) {
            // Perform search based on the entered keyword
            search(checkOutScreen.getSearchField().getText());
        }
    }

    private void populateTable(){
        clearTableModel();
        List<Booking> bookingList = applicationController.getCheckOutList();
        DefaultTableModel tableModel = checkOutScreen.getTableModel();

        for (int i = 0; i < bookingList.size(); i++){
            Object[] obj = new Object[11];
            obj[0] = bookingList.get(i).getBookingID();
            obj[1] = bookingList.get(i).getFirstName();
            obj[2] = bookingList.get(i).getLastName();
            obj[3] = bookingList.get(i).getPhoneNumber();
            obj[4] = bookingList.get(i).getEmailAddress();
            obj[5] = bookingList.get(i).getCheck_in_date();
            obj[6] = bookingList.get(i).getCheck_out_date();
            obj[7] = bookingList.get(i).getRoomType();
            obj[8] = bookingList.get(i).getRoomCapacity();
            obj[9] = bookingList.get(i).getUniqueID();
            obj[10] = bookingList.get(i).getDaysStayed();
            tableModel.addRow(obj);
        }
        checkOutScreen.setTableModel(tableModel);
    }

    private void search(String keyword) {
        DefaultTableModel tableModel = checkOutScreen.getTableModel();
        tableModel.setRowCount(0); // Clear existing rows in the table

        if (keyword.isEmpty()) {
            // If the search keyword is empty, refresh the table with the original list
            populateTable();
        } else {
            for (Booking booking : applicationController.getCheckOutList()) {
                if (booking.getEmailAddress().contains(keyword)) {
                    tableModel.addRow(new Object[]{
                            booking.getBookingID(),
                            booking.getFirstName(),
                            booking.getLastName(),
                            booking.getPhoneNumber(),
                            booking.getEmailAddress(),
                            booking.getCheck_in_date(),
                            booking.getCheck_out_date(),
                            booking.getRoomType(),
                            booking.getRoomCapacity(),
                            booking.getUniqueID(),
                            booking.getDaysStayed()
                    });
                }
                else if (booking.getFirstName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            booking.getBookingID(),
                            booking.getFirstName(),
                            booking.getLastName(),
                            booking.getPhoneNumber(),
                            booking.getEmailAddress(),
                            booking.getCheck_in_date(),
                            booking.getCheck_out_date(),
                            booking.getRoomType(),
                            booking.getRoomCapacity(),
                            booking.getUniqueID(),
                            booking.getDaysStayed()
                    });
                }
                else if (booking.getLastName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            booking.getBookingID(),
                            booking.getFirstName(),
                            booking.getLastName(),
                            booking.getPhoneNumber(),
                            booking.getEmailAddress(),
                            booking.getCheck_in_date(),
                            booking.getCheck_out_date(),
                            booking.getRoomType(),
                            booking.getRoomCapacity(),
                            booking.getUniqueID(),
                            booking.getDaysStayed()
                    });
                }
            }
        }
    }

    private void clearTableModel() {
        DefaultTableModel tableModel = checkOutScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    } // end of clearTableModel

} // end of CheckOutController class 