package midproject.client.controller;

import midproject.client.view.CancelBookingScreen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.rmi.RemoteException;
import javax.swing.JButton;

public class CancelBookingController implements ActionListener{
    private CancelBookingScreen cancelBookingScreen;
    private ApplicationController applicationController;

    public CancelBookingController(CancelBookingScreen cancelBookingScreen, ApplicationController applicationController) {
        this.cancelBookingScreen = cancelBookingScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setUpListeners();
        applicationController.switchScreen(cancelBookingScreen);
    } // end of run

    private void setUpListeners(){
        cancelBookingScreen.getCancelBookingButton().addActionListener(this);
        cancelBookingScreen.getClearButton().addActionListener(this);
        setUpButtonHoverEffects();
    } // end of setUpListeners

    public void actionPerformed(ActionEvent e){
        if (e.getSource() == cancelBookingScreen.getCancelBookingButton()) {
            try {
                cancel();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == cancelBookingScreen.getClearButton()) {
            clear();
        }
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to clear button
        JButton clearButton = cancelBookingScreen.getClearButton();
        int normalWidthClearButton = clearButton.getWidth();
        int normalHeightClearButton = clearButton.getHeight();
        JButton cancelBookingButton = cancelBookingScreen.getCancelBookingButton();
        int normalWidthCancelBookingButton = cancelBookingButton.getWidth();
        int normalHeightCancelBookingButton = cancelBookingButton.getHeight();

        clearButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                clearButton.setBackground(new Color(112, 128, 144)); // Dark grey
                clearButton.setSize(normalWidthClearButton + 5, normalHeightClearButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                clearButton.setBackground(new Color(192, 192, 192)); // Light grey
                clearButton.setSize(normalWidthClearButton, normalHeightClearButton);
            }
        });

        // Add hover effect to cancel booking button
        cancelBookingButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                cancelBookingButton.setBackground(new Color(255,82,82)); // Dark red
                cancelBookingButton.setSize(normalWidthCancelBookingButton + 5, normalHeightCancelBookingButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                cancelBookingButton.setBackground(new Color(205, 92, 92)); // Light red
                cancelBookingButton.setSize(normalWidthCancelBookingButton, normalHeightCancelBookingButton);
            }
        });
    }


    private void cancel() throws RemoteException {
        // Get the details of the booking to be canceled
        String bookingID = cancelBookingScreen.getBookingIDField().getText();
        Object[] cancelBooking = applicationController.getMidProjectInterface().cancelBooking(bookingID);
        applicationController.handleIncomingData(cancelBooking);
        if (cancelBooking[0].equals("CANCEL_BOOKING_SUCCESSFUL")){
            clear();
        }
    } // end of cancel

    private void clear(){
        cancelBookingScreen.getBookingIDField().setText(null);
    } // end of clear
} // end of CancelBookingController class
