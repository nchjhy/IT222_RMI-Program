package midproject.client.controller;

import midproject.client.view.BookingScreen;
import midproject.utilities.RangeEvaluator;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.UUID;
import javax.swing.*;

public class BookingController implements ActionListener {
    private final BookingScreen bookingScreen;
    private final ApplicationController applicationController;

    public BookingController(BookingScreen bookingScreen, ApplicationController applicationController) {
        this.bookingScreen = bookingScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setUpListeners();
        updateRoomTypeDropdown();
        applicationController.switchScreen(bookingScreen);
    }

    private void setUpListeners() {
        bookingScreen.getSubmitButton().addActionListener(this);
        bookingScreen.getClearButton().addActionListener(this);
        bookingScreen.getRoomTypeComboBox().addActionListener(this);
        setUpButtonHoverEffects();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bookingScreen.getSubmitButton()) {
            try {
                submit();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == bookingScreen.getClearButton()) {
            clear();
        } else if (e.getSource() == bookingScreen.getRoomTypeComboBox() && bookingScreen.getRoomTypeComboBox().getSelectedIndex() > 0) {
            Object item = bookingScreen.getRoomTypeComboBox().getSelectedItem();
            try {
                applicationController.requestUpdate("UPDATE_DATA");
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
            showRoomImage();
            updateRoomTypeDropdown();
            bookingScreen.getRoomTypeComboBox().setSelectedItem(item);
        }
    }

    private void setUnavailableDates(){
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        for (int i = 0; i < applicationController.getRoomsList().size(); i++){
            if (applicationController.getRoomsList().get(i).getRoomType().equals(bookingScreen.getRoomTypeComboBox().getSelectedItem())){
                for (int j = 0; j < applicationController.getRoomsList().get(i).getBookedDates().size(); j++){
                    if (applicationController.getRoomsList().get(i).getActive() && !applicationController.getBookingList().get(j).getStatus().equals("pending")){
                        RangeEvaluator evaluator = new RangeEvaluator();
                        if (!applicationController.getRoomsList().get(i).getBookedDates().isEmpty()){
                            try {
                                Object[] bdate = applicationController.getRoomsList().get(i).getBookedDates().get(j);
                                evaluator.setStartDate(dateFormat.parse(bdate[0].toString()));
                                evaluator.setEndDate(dateFormat.parse(bdate[1].toString()));
                                bookingScreen.getCheckInChooser().getJCalendar().getDayChooser().addDateEvaluator(evaluator);
                                bookingScreen.getCheckInChooser().getJCalendar().setDate(Calendar.getInstance().getTime());
                                bookingScreen.getCheckOutChooser().getJCalendar().getDayChooser().addDateEvaluator(evaluator);
                                bookingScreen.getCheckOutChooser().getJCalendar().setDate(Calendar.getInstance().getTime());
                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                        }
                    }
                }
                for (int k = 0; k < applicationController.getRoomsList().get(i).getDisabledDates().size(); k++){
                    if (applicationController.getRoomsList().get(i).getActive() && !applicationController.getBookingList().get(k).getStatus().equals("pending")){
                        RangeEvaluator evaluator = new RangeEvaluator();
                        if (!applicationController.getRoomsList().get(i).getDisabledDates().isEmpty()){
                            try {
                                Object[] ddate = applicationController.getRoomsList().get(i).getDisabledDates().get(k);
                                evaluator.setStartDate(dateFormat.parse(ddate[0].toString()));
                                evaluator.setEndDate(dateFormat.parse(ddate[1].toString()));
                                bookingScreen.getCheckInChooser().getJCalendar().getDayChooser().addDateEvaluator(evaluator);
                                bookingScreen.getCheckInChooser().getJCalendar().setDate(Calendar.getInstance().getTime());
                                bookingScreen.getCheckOutChooser().getJCalendar().getDayChooser().addDateEvaluator(evaluator);
                                bookingScreen.getCheckOutChooser().getJCalendar().setDate(Calendar.getInstance().getTime());
                            } catch (ParseException e) {
                                throw new RuntimeException(e);
                            }
                        }

                    }
                }
            }
        }
    }


    private void showRoomImage() {
        String selectedRoomType = (String) bookingScreen.getRoomTypeComboBox().getSelectedItem();
        ImageIcon icon = null;

        for (int i = 0; i < applicationController.getRoomsList().size(); i++){
            if (selectedRoomType.equals(applicationController.getRoomsList().get(i).getRoomType())){
                icon = new ImageIcon(applicationController.getRoomsList().get(i).getImgSrc());
                bookingScreen.getRoomCapacityField().setText(String.valueOf(applicationController.getRoomsList().get(i).getRoomCapacity()));
                setUnavailableDates();
            }
        }

//        if (selectedRoomType.equals("Pair Room")) {
//            icon = new ImageIcon();
//            bookingScreen.getRoomCapacityField().setText("1-2 pax");
//        } else if (selectedRoomType.equals("Family Room")) {
//            icon = new ImageIcon("src/main/java/midproject/utilities/Fam_room.jpg");
//            bookingScreen.getRoomCapacityField().setText("2-5 pax");
//        } else if (selectedRoomType.equals("Large Room")) {
//            icon = new ImageIcon("src/main/java/midproject/utilities/large_room.jpg");
//            bookingScreen.getRoomCapacityField().setText("5-12 pax");
//        }
        JOptionPane.showMessageDialog(null, new JLabel(icon), "Room Image", JOptionPane.PLAIN_MESSAGE);
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to clear button
        JButton clearButton = bookingScreen.getClearButton();
        int normalWidthClearButton = clearButton.getWidth();
        int normalHeightClearButton = clearButton.getHeight();
        JButton submitButton = bookingScreen.getSubmitButton();
        int normalWidthSubmitButton = submitButton.getWidth();
        int normalHeightSubmitButton = submitButton.getHeight();

        clearButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                clearButton.setBackground(new Color(112, 128, 144)); // Dark grey
                clearButton.setSize(normalWidthClearButton + 5, normalHeightClearButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                clearButton.setBackground(new Color(192, 192, 192)); // Light grey
                clearButton.setSize(normalWidthClearButton, normalHeightClearButton);
            }
        });

        // Add hover effect to submit button
        submitButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                submitButton.setBackground(new Color(37,167,124)); // Dark green
                submitButton.setSize(normalWidthSubmitButton + 5, normalHeightSubmitButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                submitButton.setBackground(new Color(143, 188, 143)); // Light green
                submitButton.setSize(normalWidthSubmitButton, normalHeightSubmitButton);
            }
        });
    }

    private void submit() throws RemoteException {
        String firstName = bookingScreen.getFirstNameField().getText();
        String lastName = bookingScreen.getLastNameField().getText();
        String phoneNumber = bookingScreen.getPhoneField().getText();
        String email = bookingScreen.getEmailField().getText().toLowerCase();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // Check if the date choosers return non-null values
        Date checkInDateObj = bookingScreen.getCheckInChooser().getDate();
        Date checkOutDateObj = bookingScreen.getCheckOutChooser().getDate();

        // Check if either of the dates are null before formatting
        if (checkInDateObj != null && checkOutDateObj != null) {
            String checkInDate = dateFormat.format(checkInDateObj);
            String checkOutDate = dateFormat.format(checkOutDateObj);
            System.out.println(checkInDate + "-" + checkOutDate);

            String roomType = (String) bookingScreen.getRoomTypeComboBox().getSelectedItem();
            String roomCapacity = bookingScreen.getRoomCapacityField().getText();
            String uniqueID = UUID.randomUUID().toString();

            Object[] booking = applicationController.getMidProjectInterface().booking(firstName, lastName, phoneNumber, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID);
            applicationController.handleIncomingData(booking);
        } else {
            // Handle the case when either check-in or check-out date is null
            JOptionPane.showMessageDialog(null,"Fields must not be empty");
        }
    }

    private void updateRoomTypeDropdown() {
        JComboBox<String> roomTypeComboBox = bookingScreen.getRoomTypeComboBox();
        roomTypeComboBox.removeAllItems(); // Clear existing items
        roomTypeComboBox.addItem("Choose Room Type"); // Add default item
        for (int i = 0; i < applicationController.getRoomsList().size(); i++){
            roomTypeComboBox.addItem(applicationController.getRoomsList().get(i).getRoomType());
        }
    }
    
    private void clear() {
        bookingScreen.getFirstNameField().setText(null);
        bookingScreen.getLastNameField().setText(null);
        bookingScreen.getPhoneField().setText(null);
        bookingScreen.getEmailField().setText(null);
        bookingScreen.getCheckOutChooser().setDate(null);
        bookingScreen.getCheckInChooser().setDate(null);
        bookingScreen.getRoomTypeComboBox().setSelectedItem("Choose Room Type");
        bookingScreen.getRoomCapacityField().setText(null);
    }
} // enc of BookingController class 

