package midproject.client.controller;

import midproject.client.view.AnnouncementScreen;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;

public class AnnouncementController implements ActionListener {
    private final AnnouncementScreen announcementScreen;
    private final ApplicationController applicationController;

    public AnnouncementController(AnnouncementScreen announcementScreen, ApplicationController applicationController) {
        this.announcementScreen = announcementScreen;
        this.applicationController = applicationController;
    }

    public void run() throws RemoteException {
        setupListeners();
        populate();
        applicationController.switchScreen(announcementScreen);
    }

    private void setupListeners() {
        announcementScreen.getAnnouceButton().addActionListener(this);
        setUpButtonHoverEffects();
    }

    private void setUpButtonHoverEffects() {
        JButton announceButton = announcementScreen.getAnnouceButton();
        int normalWidthAnnounceButton = announceButton.getWidth();
        int normalHeightAnnounceButton = announceButton.getHeight();

        // Add hover effect to login button
        announceButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                announceButton.setBackground(new Color(41,134,204)); // Dark blue
                announceButton.setSize(normalWidthAnnounceButton + 5, normalHeightAnnounceButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                announceButton.setBackground(new Color(48, 114, 163)); // Light blue
                announceButton.setSize(normalWidthAnnounceButton, normalHeightAnnounceButton);
            }
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == announcementScreen.getAnnouceButton()) {
            String announce = announcementScreen.getAnnoucementArea().getText();

            try {
                Object[] announcement = applicationController.getMidProjectInterface().announce(applicationController.getAccount().getFirstName() + " " + applicationController.getAccount().getLastName(), announce);
                applicationController.handleIncomingData(announcement);

                announcementScreen.getAnnoucementArea().setText(null);
                populate();
                announcementScreen.repaint();
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void populate() throws RemoteException {
        Object[] announcements = applicationController.getMidProjectInterface().fetchAnnouncements(applicationController.getLoginTime());
        applicationController.handleIncomingData(announcements);
        announcementScreen.getAnnouncementListModel().clear();
        announcementScreen.setAnnouncementListData(applicationController.getAnnouncements());
    }
} // end of AnnouncementController
