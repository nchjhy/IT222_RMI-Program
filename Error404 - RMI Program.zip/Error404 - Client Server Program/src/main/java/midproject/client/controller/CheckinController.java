package midproject.client.controller;

import javax.swing.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.rmi.RemoteException;
import midproject.client.view.CheckinScreen;

public class CheckinController implements ActionListener {
    private CheckinScreen checkinScreen;
    private ApplicationController applicationController;

    public CheckinController(CheckinScreen checkinScreen, ApplicationController applicationController) {
        this.checkinScreen = checkinScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setUpListeners();
        applicationController.switchScreen(checkinScreen);
    }

    private void setUpListeners() {
        checkinScreen.getCheckInButton().addActionListener(this);
        checkinScreen.getClearButton().addActionListener(this);
        setUpButtonHoverEffects();
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to clear button
        JButton clearButton = checkinScreen.getClearButton();
        int normalWidthClearButton = clearButton.getWidth();
        int normalHeightClearButton = clearButton.getHeight();
        JButton checkInButton = checkinScreen.getCheckInButton();
        int normalWidthCheckInButton = checkInButton.getWidth();
        int normalHeightCheckInButton = checkInButton.getHeight();

        clearButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                clearButton.setBackground(new Color(112, 128, 144)); // Dark grey
                clearButton.setSize(normalWidthClearButton + 5, normalHeightClearButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                clearButton.setBackground(new Color(192, 192, 192)); // Light grey
                clearButton.setSize(normalWidthClearButton, normalHeightClearButton);
            }
        });

        // Add hover effect to check-in button
        checkInButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                checkInButton.setBackground(new Color(37,167,124)); // Dark green
                checkInButton.setSize(normalWidthCheckInButton + 5, normalHeightCheckInButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                checkInButton.setBackground(new Color(143, 188, 143)); // Light green
                checkInButton.setSize(normalWidthCheckInButton, normalHeightCheckInButton);
            }
        });
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == checkinScreen.getCheckInButton()) {
            try {
                submit();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == checkinScreen.getClearButton()) {
            clear();
        }
    }

    private void submit() throws RemoteException {
        String bookingID = checkinScreen.getBookingIDField().getText();
        Object[] checkin = applicationController.getMidProjectInterface().checkin(bookingID);
        applicationController.handleIncomingData(checkin);
        if (checkin[0].equals("CHECKIN_SUCCESSFUL")){
            clear();
        }
    }

    private void clear() {
        checkinScreen.getBookingIDField().setText(null);
    }
} // end of CheckinController class
