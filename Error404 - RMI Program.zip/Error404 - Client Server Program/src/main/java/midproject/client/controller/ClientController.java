package midproject.client.controller;

import midproject.client.view.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.io.Serializable;
import java.rmi.RemoteException;
import javax.swing.*;

public class ClientController implements ActionListener, Serializable {
    private final ApplicationController applicationController;
    private final ClientHomeScreen clientHomeScreen;
    private final ProfileScreen profileScreen = new ProfileScreen();
    private Timer timer;
    private float alpha = 0.0f;
    private boolean fadeIn = true;

    public ClientController(ClientHomeScreen clientHomeScreen, ApplicationController applicationController) {
        this.clientHomeScreen = clientHomeScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        updateWelcomeLabel();
        updateProfile();
        setupListeners();
        applicationController.switchScreen(clientHomeScreen);
        animateWelcomeLabel();
    }

    private void setupListeners() {
        clientHomeScreen.getBookingButton().addActionListener(this);
        clientHomeScreen.getBookNowButton().addActionListener(this);
        clientHomeScreen.getViewBookingButton().addActionListener(this);
        clientHomeScreen.getProfileButton().addActionListener(this);
        clientHomeScreen.getAnnouncementButton().addActionListener(this);
        clientHomeScreen.getLogoutButton().addActionListener((this));
        setUpButtonHoverEffects();
    }

    // controls the navigation of the menu by running their respective controllers
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();

        if (source == clientHomeScreen.getLogoutButton()) {
            try {
                Object[] logout = applicationController.getMidProjectInterface().logout(applicationController.getAccount());
                applicationController.handleIncomingData(logout);

                applicationController.getAccount().setOnline(false);
                applicationController.getLoginController().run();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (source == clientHomeScreen.getViewBookingButton()) {
            BookingHistoryScreen bookingHistoryScreen = new BookingHistoryScreen();
            bookingHistoryScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(clientHomeScreen)); // when the back button is pressed
            BookingHistoryController bookingHistoryController = new BookingHistoryController(bookingHistoryScreen, applicationController);
            bookingHistoryController.run();
        } else if (source == clientHomeScreen.getAnnouncementButton()) {
            AnnouncementScreen announcementScreen = new AnnouncementScreen();
            announcementScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(clientHomeScreen)); // when the back button is pressed
            AnnouncementController announcementController = new AnnouncementController(announcementScreen, applicationController);
            try {
                announcementController.run();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (source == clientHomeScreen.getBookingButton()) {
            BookingScreen bookingScreen = new BookingScreen();
            bookingScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(clientHomeScreen)); // when the back button is pressed
            BookingController bookingController = new BookingController(bookingScreen, applicationController);
            bookingController.run();
        } else if (source == clientHomeScreen.getProfileButton()) {
            profileScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(clientHomeScreen)); // when the back button is pressed
            ProfileController profileController = new ProfileController(profileScreen, applicationController);
            profileController.run();
        }
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to Ban button
        JButton bookNowButton = clientHomeScreen.getBookNowButton();
        int normalWidthBookNowButton = bookNowButton.getWidth();
        int normalHeightBookNowButton = bookNowButton.getHeight();

        JButton viewBookingButton = clientHomeScreen.getViewBookingButton();
        int normalWidthViewBookingButton = viewBookingButton.getWidth();
        int normalHeightViewBookingButton = viewBookingButton.getHeight();

        JButton bookingButton = clientHomeScreen.getBookingButton();
        int normalWidthBookingButton = bookingButton.getWidth();
        int normalHeightBookingButton = bookingButton.getHeight();

        JButton profileButton = clientHomeScreen.getProfileButton();
        int normalWidthProfileButton = profileButton.getWidth();
        int normalHeightProfileButton = profileButton.getHeight();

        JButton announcementButton = clientHomeScreen.getAnnouncementButton();
        int normalWidthAnnouncementButton = announcementButton.getWidth();
        int normalHeightAnnouncementButton = announcementButton.getHeight();

        JButton logoutButton = clientHomeScreen.getLogoutButton();
        int normalWidthLogoutButton = logoutButton.getWidth();
        int normalHeightLogoutButton = logoutButton.getHeight();

        // Add hover effect to book now button
        bookNowButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                bookNowButton.setBackground(new Color(41,134,204));
                bookNowButton.setSize(normalWidthBookNowButton + 5, normalHeightBookNowButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                bookNowButton.setBackground(new Color(30, 75, 135));
                bookNowButton.setSize(normalWidthBookNowButton, normalHeightBookNowButton);
            }
        });

        // Add hover effect to Booking button
        bookingButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                bookingButton.setBackground(new Color(41,134,204));
                bookingButton.setSize(normalWidthBookingButton + 5, normalHeightBookingButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                bookingButton.setBackground(new Color(30, 75, 135));
                bookingButton.setSize(normalWidthBookingButton, normalHeightBookingButton);
            }
        });

        // Add hover effect to View Booking button
        viewBookingButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                viewBookingButton.setBackground(new Color(41,134,204));
                viewBookingButton.setSize(normalWidthBookingButton + 5, normalHeightBookingButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                viewBookingButton.setBackground(new Color(30, 75, 135));
                viewBookingButton.setSize(normalWidthViewBookingButton, normalHeightViewBookingButton);
            }
        });


        // Add hover effect to profile button
        profileButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                profileButton.setBackground(new Color(41,134,204));
                profileButton.setSize(normalWidthProfileButton + 5, normalHeightProfileButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                profileButton.setBackground(new Color(30, 75, 135));
                profileButton.setSize(normalWidthProfileButton, normalHeightProfileButton);
            }
        });

        // Add hover effect to announcement button
        announcementButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                announcementButton.setBackground(new Color(41,134,204));
                announcementButton.setSize(normalWidthAnnouncementButton + 5, normalHeightAnnouncementButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                announcementButton.setBackground(new Color(30, 75, 135));
                announcementButton.setSize(normalWidthAnnouncementButton, normalHeightAnnouncementButton);
            }
        });

        // Add hover effect to logout button
        logoutButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                logoutButton.setBackground(new Color(255,82,82)); // Dark red
                logoutButton.setSize(normalWidthLogoutButton + 5, normalHeightLogoutButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                logoutButton.setBackground(new Color(205, 92, 92));  // Light red
                logoutButton.setSize(normalWidthLogoutButton, normalHeightLogoutButton);
            }
        });
    }

    private void updateWelcomeLabel(){
        clientHomeScreen.getWelcomeLabel().setText("Welcome to Error 404 Transient, " + applicationController.getAccount().getFirstName() + "!");
    }

    private void updateProfile(){
        profileScreen.getNameLabel().setText("Name: " + applicationController.getAccount().getFirstName() + " " + applicationController.getAccount().getLastName());
        profileScreen.getEmailLabel().setText("Email: " + applicationController.getAccount().getEmail());
        profileScreen.getPhoneNumberLabel().setText("Phone: " + applicationController.getAccount().getPhoneNumber());
        profileScreen.getPasswordLabel().setText("Password: " + applicationController.getAccount().getPassword());
    }

    private void animateWelcomeLabel() {
        timer = new Timer(170, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (fadeIn) {
                    alpha += 0.05f;
                    if (alpha >= 1.0f) {
                        alpha = 1.0f;
                        fadeIn = false;
                    }
                } else {
                    alpha -= 0.05f;
                    if (alpha <= 0.0f) {
                        alpha = 0.0f;
                        fadeIn = true;
                    }
                }
                clientHomeScreen.updateWelcomeLabelAlpha(alpha);
            }
        });
        timer.start();
    }

    public ClientHomeScreen getClientHomeScreen() { return clientHomeScreen; }
} // end of ClientController class
