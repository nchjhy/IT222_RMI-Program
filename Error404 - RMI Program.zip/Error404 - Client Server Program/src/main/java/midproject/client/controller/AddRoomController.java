package midproject.client.controller;

import midproject.client.view.AddRoomScreen;
import midproject.shared.Room;
import midproject.utilities.JSONUtility;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.List;

public class AddRoomController implements ActionListener {
    private AddRoomScreen addRoomScreen;
    private ApplicationController applicationController;

    public AddRoomController(AddRoomScreen addRoomScreen, ApplicationController applicationController) {
        this.addRoomScreen = addRoomScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setUpListeners();
        updateRoomTable();
        applicationController.switchScreen(addRoomScreen);
        addRoomScreen.getAddRoomButton().addActionListener(this);
        setUpButtonHoverEffects();
    }

    private void setUpListeners() {
        addRoomScreen.addRefreshButtonListener(new RefreshButtonListener());
    }

    private class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                applicationController.requestUpdate("UPDATE_DATA");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addRoomScreen.getAddRoomButton()) {
            try {
                showAddRoomDialog();
                JSONUtility.saveRoomsJSON(applicationController.getRoomsList());
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    private void showAddRoomDialog() throws RemoteException {
        JTextField roomTypeField = new JTextField();
        JTextField roomCapacityField = new JTextField();
        JTextField imgSrcField = new JTextField();
    
        JPanel dialogPanel = new JPanel(new GridLayout(0, 1));
        dialogPanel.add(new JLabel("Room Type:"));
        dialogPanel.add(roomTypeField);
        dialogPanel.add(new JLabel("Room Capacity:"));
        dialogPanel.add(roomCapacityField);
        dialogPanel.add(new JLabel("Room Image Src:"));
        dialogPanel.add(imgSrcField);
    
        int result = JOptionPane.showConfirmDialog(null, dialogPanel, "Add Room", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            String roomType = roomTypeField.getText();
            String roomCapacity = roomCapacityField.getText();
            String imgSrc = imgSrcField.getText();
    
            Object[] addRoom = applicationController.getMidProjectInterface().addRoom(roomType, roomCapacity, imgSrc);
            applicationController.handleIncomingData(addRoom);
            updateRoomTable();
        }
    }
    
    private void setUpButtonHoverEffects() {
        // Add hover effect to add room button
        JButton addButton = addRoomScreen.getAddRoomButton();
        int normalWidthAddButton = addButton.getWidth();
        int normalHeightAddButton = addButton.getHeight();

        // Add hover effect to add room button
        addButton.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                addButton.setBackground(new java.awt.Color(37, 167, 124)); // Dark green
                addButton.setSize(normalWidthAddButton + 5, normalHeightAddButton + 5);
            }

            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                addButton.setBackground(new java.awt.Color(143, 188, 143)); // Light green
                addButton.setSize(normalWidthAddButton, normalHeightAddButton);
            }
        });
    }

    // Method to update the room table in the Add Room screen
    private void updateRoomTable() {
        clearTableModel();
        List<Room> roomsList = applicationController.getRoomsList();
        DefaultTableModel tableModel = addRoomScreen.getTableModel();
        for (int i = 0; i < roomsList.size(); i++){
            Object[] obj = new Object[2];
            obj[0] = roomsList.get(i).getRoomType();
            obj[1] = roomsList.get(i).getRoomCapacity();
            tableModel.addRow(obj);
        }
        addRoomScreen.setTableModel(tableModel);
        addRoomScreen.repaint();
    }

    private void clearTableModel() {
        DefaultTableModel tableModel = addRoomScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    } // end of clearTableModel
} // end of AddRoomController class 
