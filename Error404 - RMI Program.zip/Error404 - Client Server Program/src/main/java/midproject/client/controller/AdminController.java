package midproject.client.controller;

import midproject.client.view.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.io.Serializable;
import java.rmi.RemoteException;

public class AdminController implements ActionListener, Serializable {
    private ApplicationController applicationController;
    private AdminHomeScreen adminHomeScreen;
    private ProfileScreen profileScreen = new ProfileScreen();

    public AdminController(AdminHomeScreen adminHomeScreen, ApplicationController applicationController) {
        this.adminHomeScreen = adminHomeScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        updateWelcomeLabel();
        updateProfile();
        setupListeners();
        applicationController.switchScreen(adminHomeScreen);
    } // end of run

    private void setupListeners() {
        adminHomeScreen.getAppointmentButton().addActionListener(this);
        adminHomeScreen.getBookNowButton().addActionListener(this);
        adminHomeScreen.getViewAppointmentButton().addActionListener(this);
        adminHomeScreen.getProfileButton().addActionListener(this);
        adminHomeScreen.getBookingHistoryButton().addActionListener(this);
        adminHomeScreen.getAnnouncementButton().addActionListener(this);
        adminHomeScreen.getGuestButton().addActionListener(this);
        adminHomeScreen.getLogoutButton().addActionListener((this));
        adminHomeScreen.getUserButton().addActionListener((this));
        adminHomeScreen.getManageButton().addActionListener((this));
        setUpButtonHoverEffects();
    } // end of setupListeners

    // controls the navigation of the menu by running their respective controllers
    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source == adminHomeScreen.getLogoutButton()) {
            try {
                Object[] logout = applicationController.getMidProjectInterface().logout(applicationController.getAccount());
                applicationController.handleIncomingData(logout);

                applicationController.getAccount().setOnline(false);
                applicationController.getLoginController().run();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (source == adminHomeScreen.getViewAppointmentButton()) {
            ViewAppointmentsScreen viewAppointmentsScreen = new ViewAppointmentsScreen();
            viewAppointmentsScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            ViewAppointmentsController viewAppointmentsController = new ViewAppointmentsController(viewAppointmentsScreen, applicationController);
            viewAppointmentsController.run();
        } else if (source == adminHomeScreen.getBookingHistoryButton()) {
            BookingHistoryScreen bookingHistoryScreen = new BookingHistoryScreen();
            bookingHistoryScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            BookingHistoryController bookingHistoryController = new BookingHistoryController(bookingHistoryScreen, applicationController);
            bookingHistoryController.run();
        } else if (source == adminHomeScreen.getAnnouncementButton()) {
            AnnouncementScreen announcementScreen = new AnnouncementScreen();
            announcementScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            AnnouncementController announcementController = new AnnouncementController(announcementScreen, applicationController);
            try {
                announcementController.run();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (source == adminHomeScreen.getAppointmentButton()) {
            int choice = showBookingOption();
            if (choice == JOptionPane.YES_OPTION){
                BookingScreen bookingScreen = new BookingScreen();
                bookingScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
                BookingController bookingController = new BookingController(bookingScreen, applicationController);
                bookingController.run();
            } else if (choice == JOptionPane.NO_OPTION){
                CancelBookingScreen cancelBookingScreen = new CancelBookingScreen();
                cancelBookingScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
                CancelBookingController cancelBookingController = new CancelBookingController(cancelBookingScreen, applicationController);
                cancelBookingController.run();
            }
        } else if (source == adminHomeScreen.getUserButton()) {
            UserScreen userScreen = new UserScreen();
            userScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            UserController userController = new UserController(userScreen, applicationController);
            userController.run();
        } else if (source == adminHomeScreen.getGuestButton()) {
            GuestScreen guestScreen = new GuestScreen();
            guestScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            GuestController guestController = new GuestController(guestScreen, applicationController);
            guestController.run();
        } else if (source == adminHomeScreen.getProfileButton()) {
            profileScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            ProfileController profileController = new ProfileController(profileScreen, applicationController);
            profileController.run();
        } else if (source == adminHomeScreen.getBookNowButton()) {
            CheckinScreen checkinScreen = new CheckinScreen();
            checkinScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            CheckinController checkinController = new CheckinController(checkinScreen, applicationController);
            checkinController.run();
        }
        else if (source == adminHomeScreen.getManageButton()) {
        int choice = showManageOption();
        if (choice == JOptionPane.YES_OPTION){
            AddRoomScreen addRoomScreen = new AddRoomScreen();
            addRoomScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            AddRoomController addRoomController = new AddRoomController(addRoomScreen, applicationController);
            addRoomController.run();

        } else if (choice == JOptionPane.NO_OPTION){
            DisableDateViewScreen disableDateScreen = new DisableDateViewScreen();
            disableDateScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(adminHomeScreen)); // when the back button is pressed
            DisableDateViewController disableDateController = new DisableDateViewController(disableDateScreen, applicationController);
            disableDateController.run();
        }
    }
    }

    private int showBookingOption() {
        Object[] options = {"Add Booking", "Cancel Booking"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Do you want to add or cancel a booking?",
                "Booking Option",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (choice == JOptionPane.YES_OPTION) {
            // Add Booking option selected
            //        applicationController.switchScreen(ScreenType.CHECKIN_SCREEN.getScreen());
            JOptionPane.showMessageDialog(
                    null,
                    "Booking option selected",
                    "Info",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if (choice == JOptionPane.NO_OPTION) {
            // Cancel Booking option selected
            //        applicationController.switchScreen(ScreenType.CANCELBOOKING_SCREEN.getScreen());
            JOptionPane.showMessageDialog(
                    null,
                    "Cancel Booking option selected",
                    "Info",
                    JOptionPane.INFORMATION_MESSAGE);
        }
        return choice;
    }

    private int showManageOption() {
        Object[] options = {"Add Rooms", "Disable Dates"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Do you want to add a room or disable a date?",
                "Manage Option",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (choice == JOptionPane.YES_OPTION) {
            // Add Booking option selected
            //        applicationController.switchScreen(ScreenType.CHECKIN_SCREEN.getScreen());
            JOptionPane.showMessageDialog(
                    null,
                    "Add Rooms option selected",
                    "Info",
                    JOptionPane.INFORMATION_MESSAGE);

        } else if (choice == JOptionPane.NO_OPTION) {
            // Cancel Booking option selected
            //        applicationController.switchScreen(ScreenType.CANCELBOOKING_SCREEN.getScreen());
            JOptionPane.showMessageDialog(
                    null,
                    "Disable dates option selected",
                    "Info",
                    JOptionPane.INFORMATION_MESSAGE);
        }
        return choice;
    }

    private void updateWelcomeLabel(){
        adminHomeScreen.getWelcomeLabel().setText("Welcome, " + applicationController.getAccount().getFirstName() + "!");
    }

    private void updateProfile(){
        profileScreen.getNameLabel().setText("Name: " + applicationController.getAccount().getFirstName() + " " + applicationController.getAccount().getLastName());
        profileScreen.getEmailLabel().setText("Email: " + applicationController.getAccount().getEmail());
        profileScreen.getPhoneNumberLabel().setText("Phone: " + applicationController.getAccount().getPhoneNumber());
        profileScreen.getPasswordLabel().setText("Password: " + applicationController.getAccount().getPassword());
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to Ban button
        JButton bookNowButton = adminHomeScreen.getBookNowButton();
        int normalWidthBookNowButton = bookNowButton.getWidth();
        int normalHeightBookNowButton = bookNowButton.getHeight();

        JButton viewAppointmentButton = adminHomeScreen.getViewAppointmentButton();
        int normalWidthViewAppointmentButton = viewAppointmentButton.getWidth();
        int normalHeightViewAppointmentButton = viewAppointmentButton.getHeight();

        JButton appointmentButton = adminHomeScreen.getAppointmentButton();
        int normalWidthAppointmentButton = appointmentButton.getWidth();
        int normalHeightAppointmentButton = appointmentButton.getHeight();

        JButton profileButton = adminHomeScreen.getProfileButton();
        int normalWidthProfileButton = profileButton.getWidth();
        int normalHeightProfileButton = profileButton.getHeight();

        JButton bookingHistoryButton = adminHomeScreen.getBookingHistoryButton();
        int normalWidthBookingHistoryButton = bookingHistoryButton.getWidth();
        int normalHeightBookingHistoryButton = bookingHistoryButton.getHeight();

        JButton announcementButton = adminHomeScreen.getAnnouncementButton();
        int normalWidthAnnouncementButton = announcementButton.getWidth();
        int normalHeightAnnouncementButton = announcementButton.getHeight();

        JButton guestButton = adminHomeScreen.getGuestButton();
        int normalWidthGuestButton = guestButton.getWidth();
        int normalHeightGuestButton = guestButton.getHeight();

        JButton userButton = adminHomeScreen.getUserButton();
        int normalWidthUserButton = userButton.getWidth();
        int normalHeightUserButton = userButton.getHeight();

        JButton manageButton = adminHomeScreen.getManageButton();
        int normalWidthManageButton = manageButton.getWidth();
        int normalHeightManageButton = manageButton.getHeight();

        JButton logoutButton = adminHomeScreen.getLogoutButton();
        int normalWidthLogoutButton = logoutButton.getWidth();
        int normalHeightLogoutButton = logoutButton.getHeight();

        // Add hover effect to book now button
        bookNowButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                bookNowButton.setBackground(new Color(41,134,204));
                bookNowButton.setSize(normalWidthBookNowButton + 5, normalHeightBookNowButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                bookNowButton.setBackground(new Color(30, 75, 135));
                bookNowButton.setSize(normalWidthBookNowButton, normalHeightBookNowButton);
            }
        });

        // Add hover effect to View Appointment booking button
        viewAppointmentButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                viewAppointmentButton.setBackground(new Color(41,134,204));
                viewAppointmentButton.setSize(normalWidthViewAppointmentButton + 5, normalHeightViewAppointmentButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                viewAppointmentButton.setBackground(new Color(30, 75, 135));
                viewAppointmentButton.setSize(normalWidthViewAppointmentButton, normalHeightViewAppointmentButton);
            }
        });

        // Add hover effect to View Appointment booking button
        appointmentButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                appointmentButton.setBackground(new Color(41,134,204));
                appointmentButton.setSize(normalWidthAppointmentButton + 5, normalHeightAppointmentButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                appointmentButton.setBackground(new Color(30, 75, 135));
                appointmentButton.setSize(normalWidthAppointmentButton, normalHeightAppointmentButton);
            }
        });

        // Add hover effect to profile button
        profileButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                profileButton.setBackground(new Color(41,134,204));
                profileButton.setSize(normalWidthProfileButton + 5, normalHeightProfileButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                profileButton.setBackground(new Color(30, 75, 135));
                profileButton.setSize(normalWidthProfileButton, normalHeightProfileButton);
            }
        });

        // Add hover effect to booking history button
        bookingHistoryButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                bookingHistoryButton.setBackground(new Color(41,134,204));
                bookingHistoryButton.setSize(normalWidthBookingHistoryButton + 5, normalHeightBookingHistoryButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                bookingHistoryButton.setBackground(new Color(30, 75, 135));
                bookingHistoryButton.setSize(normalWidthBookingHistoryButton, normalHeightBookingHistoryButton);
            }
        });

        // Add hover effect to announcement button
        announcementButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                announcementButton.setBackground(new Color(41,134,204));
                announcementButton.setSize(normalWidthAnnouncementButton + 5, normalHeightAnnouncementButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                announcementButton.setBackground(new Color(30, 75, 135));
                announcementButton.setSize(normalWidthAnnouncementButton, normalHeightAnnouncementButton);
            }
        });

        // Add hover effect to guest button
        guestButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                guestButton.setBackground(new Color(41,134,204));
                guestButton.setSize(normalWidthGuestButton + 5, normalHeightGuestButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                guestButton.setBackground(new Color(30, 75, 135));
                guestButton.setSize(normalWidthGuestButton, normalHeightGuestButton);
            }
        });

        // Add hover effect to user button
        userButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                userButton.setBackground(new Color(41,134,204));
                userButton.setSize(normalWidthUserButton + 5, normalHeightUserButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                userButton.setBackground(new Color(30, 75, 135));
                userButton.setSize(normalWidthUserButton, normalHeightUserButton);
            }
        });

        // Add hover effect to manage button
        manageButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                manageButton.setBackground(new Color(41,134,204));
                manageButton.setSize(normalWidthManageButton + 5, normalHeightManageButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                manageButton.setBackground(new Color(30, 75, 135));
                manageButton.setSize(normalWidthManageButton, normalHeightManageButton);
            }
        });

        // Add hover effect to logout button
        logoutButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                logoutButton.setBackground(new Color(255,82,82)); // Dark red
                logoutButton.setSize(normalWidthLogoutButton + 5, normalHeightLogoutButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                logoutButton.setBackground(new Color(205, 92, 92));  // Light red
                logoutButton.setSize(normalWidthLogoutButton, normalHeightLogoutButton);
            }
        });
    }

    public AdminHomeScreen getAdminHomeScreen() { return adminHomeScreen; }
}// end of AdminController class
