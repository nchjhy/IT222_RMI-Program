package midproject.client.controller;

import midproject.client.view.LoginScreen;
import midproject.client.view.RegisterScreen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.UUID;

public class RegisterController implements ActionListener {
    private final ApplicationController applicationController;
    private final RegisterScreen registerScreen;
    private LoginScreen loginScreen;

    public RegisterController(RegisterScreen registerScreen, ApplicationController applicationController) {
        this.registerScreen = registerScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setupListeners();
        applicationController.switchScreen(registerScreen);
    }

    public void setupListeners() {
        registerScreen.getSignUpButton().addActionListener(this);
        registerScreen.getShowPassword().addActionListener(this);
        registerScreen.getClearButton().addActionListener(this);
        registerScreen.getBackButton().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerScreen.getSignUpButton()) {
            try {
                createAccount();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == registerScreen.getShowPassword()) {
            showPassword();
        } else if (e.getSource() == registerScreen.getClearButton()) {
            clear();
        } else if (e.getSource() == registerScreen.getBackButton()) {
            loginScreen = new LoginScreen();
            loginScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(loginScreen));
            LoginController loginController = new LoginController(loginScreen, applicationController);
            loginController.run();
        }
    }

    private void createAccount() throws RemoteException {
        // Get field values
        String firstName = registerScreen.getFirstNameField().getText();
        String lastName = registerScreen.getLastNameField().getText();
        String age = registerScreen.getAgeField().getText();
        String phoneNumber = registerScreen.getPhoneNumberField().getText();
        String email = registerScreen.getEmailField().getText().toLowerCase();
        String password = registerScreen.getPasswordField().getText();
        String cPassword = registerScreen.getConfirmPasswordField().getText();
        String uniqueID = UUID.randomUUID().toString();

        Object[] requestPackage = new Object[] {firstName, lastName, age, phoneNumber, email, password, cPassword, uniqueID};
        //applicationController.sendRequest("REGISTRATION_REQUEST", requestPackage);
        Object[] register = applicationController.getMidProjectInterface().register(firstName, lastName, age, phoneNumber, email, password, cPassword, uniqueID);
        applicationController.handleIncomingData(register);
        
    }

    private void showPassword() {
        if (registerScreen.getShowPassword().isSelected()) {
            registerScreen.getPasswordField().setEchoChar((char) 0);
            registerScreen.getConfirmPasswordField().setEchoChar((char) 0);
        } else {
            registerScreen.getPasswordField().setEchoChar('•');
            registerScreen.getConfirmPasswordField().setEchoChar('•');
        }
    }

    private void clear(){
        registerScreen.getFirstNameField().setText(null);
        registerScreen.getLastNameField().setText(null);
        registerScreen.getAgeField().setText(null);
        registerScreen.getPhoneNumberField().setText(null);
        registerScreen.getEmailField().setText(null);
        registerScreen.getPasswordField().setText(null);
        registerScreen.getConfirmPasswordField().setText(null);
    }
} // end of RegisterController class 
