package midproject.client.controller;

import midproject.client.model.ApplicationModel;
import midproject.client.view.AdminHomeScreen;
import midproject.client.view.ClientHomeScreen;
import midproject.client.view.DefaultScreen;
import midproject.client.view.LoginScreen;
import midproject.shared.*;
import javax.swing.*;
import java.io.Serializable;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ApplicationController implements Serializable {
    private final ApplicationModel model;
    private DefaultScreen defaultScreen; // Access DefaultScreen
    private final LoginController loginController;
    private final AdminController adminController;
    private final ClientController clientController;
    public List<Account> accounts;
    private final MidProjectInterface midProjectInterface;
    private DataRefreshCallback dataRefreshCallback;

    public ApplicationController(MidProjectInterface midProjectInterface) throws NotBoundException, RemoteException {
        model = new ApplicationModel();

        // instantiate user interface panel
        loginController = new LoginController(new LoginScreen(), this);
        adminController = new AdminController(new AdminHomeScreen(), this);
        clientController = new ClientController(new ClientHomeScreen(), this);
        accounts = new ArrayList<>();

        this.midProjectInterface = midProjectInterface;
    }

    public void start() throws RemoteException {
        defaultScreen = new DefaultScreen(); // initialize the frame of the program
        loginController.run(); // run the initial state of the user interface which is the login screen

        Object[] data = midProjectInterface.fetchData(); //request data from server
        handleIncomingData(data);

        // Create a callback object
        this.dataRefreshCallback = new DataRefreshCallbackImpl(this);

        // Register the callback with the server
        midProjectInterface.registerCallback(dataRefreshCallback);
    }

    /**
     * handles the data retrieved from the server and processes the data
     * @param message the packaged object with index 0 as the code and index 1 as the data
     */
    public void handleIncomingData(Object[] message) throws RemoteException {
        String code = (String) message[0];

        System.out.println("\nReceived data from server");
        System.out.println("Code: " + code);
        switch (code) {
            case "REQUESTED_DATA" -> {
                Object[] packagedData = (Object[]) message[1];

                List<Account> accountList = (List<Account>) packagedData[0];
                List<Booking> bookingList = (List<Booking>) packagedData[1];
                List<Booking> checkoutList = (List<Booking>) packagedData[2];
                List<Booking> guestList = (List<Booking>) packagedData[3];
                List<Room> roomsList = (List<Room>) packagedData[4];

                model.setAccountList(accountList);
                model.setBookingList(bookingList);
                model.setCheckOutList(checkoutList);
                model.setGuestList(guestList);
                model.setRoomsList(roomsList);
            }
            case "REQUESTED_ANNOUNCEMENTS" -> {
                if (message[1] != null){
                    List<Announcement> announcements = (List<Announcement>) message[1];
                    model.setAnnouncements(announcements);
                }

            }
            case "LOGIN_SUCCESSFUL" -> {
                Object[] packagedData = (Object[]) message[1];
                Account account = (Account) packagedData[0];
                String response = (String) packagedData[1];

                JOptionPane.showMessageDialog(null, response);

                // add account to model
                model.setAccount(account);
                model.getAccount().setOnline(true);
                model.setLoginTime(new Date());

                Object[] data = midProjectInterface.fetchData(); //request data from server
                handleIncomingData(data);

                if (account.isAdmin()) {
                    // switch to admin screen
                    adminController.run();
                } else {
                    // switch to client screen
                    clientController.run();
                }
            }
            case "LOGIN_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "REGISTRATION_SUCCESSFUL" -> {
                Object[] packagedData = (Object[]) message[1];
                Account account = (Account) packagedData[0];
                String response = (String) packagedData[1];

                JOptionPane.showMessageDialog(null, response);

                model.getAccountList().add(model.getAccountList().size(), account);
                switchScreen(getLoginController().getLoginScreen());
            }
            case "REGISTRATION_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "CANCEL_BOOKING_SUCCESSFUL" -> {
                Object[] packagedData = (Object[]) message[1];
                int index = (int) packagedData[0];
                String response = (String) packagedData[1];

                JOptionPane.showMessageDialog(null, response);

                model.getBookingList().get(index).setStatus("cancelled");
                if (model.getAccount().isOnline()){
                    if(getAccount().isAdmin()){
                        switchScreen(getAdminController().getAdminHomeScreen());
                    } else{
                        switchScreen(getClientController().getClientHomeScreen());
                    }
                }
            }
            case "CANCEL_BOOKING_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "DELETE_SUCCESSFUL" -> {
                int selectedRow = (int) message[1];

                JOptionPane.showMessageDialog(null, "Account has been deleted");

                model.getAccountList().remove(model.getAccountList().get(selectedRow));
            }
            case "BOOKING_SUCCESSFUL" -> {
                Object[] packagedData = (Object[]) message[1];
                Booking booking = (Booking) packagedData[0];
                String response = (String) packagedData[1];

                JOptionPane.showMessageDialog(null, response);
                model.getBookingList().add(booking);
                if (model.getAccount().isOnline()){
                    if(getAccount().isAdmin()){
                        switchScreen(getAdminController().getAdminHomeScreen());
                    } else{
                        switchScreen(getClientController().getClientHomeScreen());
                    }
                }
            }
            case "BOOKING_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "CHECKOUT_SUCCESSFUL" -> {
                Object[] packageData = (Object[]) message[1];
                Booking checkOutBooking = (Booking) packageData[0];
                JOptionPane.showMessageDialog(null, packageData[1]);

                for (int i = 0; i < getGuestList().size(); i++){
                    if (getGuestList().get(i).getBookingID().equalsIgnoreCase(checkOutBooking.getBookingID())){
                        model.getGuestList().remove(model.getGuestList().get(i));
                    }
                }

                model.getCheckOutList().add(checkOutBooking);
            }
            case "CHECKOUT_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "CHECKIN_SUCCESSFUL" -> {
                Object[] packageData = (Object[]) message[1];
                Booking checkIn = (Booking) packageData[0];
                JOptionPane.showMessageDialog(null, packageData[1]);
                
                model.getGuestList().add(checkIn);
                if (model.getAccount().isOnline()){
                    if(getAccount().isAdmin()){
                        switchScreen(getAdminController().getAdminHomeScreen());
                    } else{
                        switchScreen(getClientController().getClientHomeScreen());
                    }
                }
            }
            case "CHECKIN_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "ANNOUNCEMENT" -> {
                Announcement announcement = (Announcement) message[1];
                model.getAnnouncements().add(announcement);
            }
            case "ANNOUNCEMENT_NULL" -> {
                System.out.println("Null announcement detected");
            }
            case "BAN_SUCCESSFUL" -> {
                int selectedRow = (int) message[1];

                JOptionPane.showMessageDialog(null, "Account has been banned");

                model.getAccountList().get(selectedRow).setBanned(true);
            }

            case "UNBAN_SUCCESSFUL" -> {
                int selectedRow = (int) message[1];

                JOptionPane.showMessageDialog(null, "Account has been unbanned");

                model.getAccountList().get(selectedRow).setBanned(false);
            }
            case "LOGOUT_SUCCESSFUL" -> {
                Object[] log = (Object[]) message[1];
                int account = (int) log[0];
                String words = (String) log[1];

                JOptionPane.showMessageDialog(null, words);

                model.getAccountList().get(account).setOnline(false);
            }
            case "LOGOUT_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "NOTIFICATION" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "APPROVED" -> {
                int booking = (int) message[1];
                model.getBookingList().get(booking).setStatus("approved");
                requestUpdate("UPDATE_DATA");
                JOptionPane.showMessageDialog(null, "Booking with bookingID " + (booking + 1) + " has been approved. You may check in on the date booked.");
            }
            case "DECLINED" -> {
                int booking = (int) message[1];
                model.getBookingList().get(booking).setStatus("declined");
                JOptionPane.showMessageDialog(null, "Booking with bookingID " + (booking + 1) + " has been declined. You can try to book another booking.");
            }
            case "EDITED_BOOKING" -> {
                int booking = (int) message[1];
                requestUpdate("UPDATE_DATA");
                JOptionPane.showMessageDialog(null, "Booking with bookingID " + (booking + 1) + " has been edited. Please re-verify information before it is re-subjected for approval in a few minutes.");
            }
            case "ADD_ROOM_SUCCESSFUL" -> {
                Object[] packagedData = (Object[]) message[1];
                Room room = (Room) packagedData[0];
                String response = (String) packagedData[1];

                model.getRoomsList().add(room);
                
                JOptionPane.showMessageDialog(null, response);
            }
            case "ADD_ROOM_FAILED" -> {
                String response = (String) message[1];
                JOptionPane.showMessageDialog(null, response);
            }
            case "DISABLED_DATES" -> {
                String response = (String) message[1];
                requestUpdate("UPDATE_DATA");
                switchScreen(getAdminController().getAdminHomeScreen());
                JOptionPane.showMessageDialog(null, response);
            }
        }
    } // end of handleIncomingData
    
    /**
     * switches out the primary scene of the user interface with the necessary panel
     * @param newScreen the screen to be displayed
     */
    public void switchScreen(JPanel newScreen) {
        System.out.println("Switching to screen: " + newScreen.getClass().getSimpleName());
        if (defaultScreen == null) {
            defaultScreen = new DefaultScreen();
        }
        defaultScreen.getContentPane().removeAll();
        defaultScreen.getContentPane().repaint();
        defaultScreen.getContentPane().add(newScreen);
        defaultScreen.revalidate();
        defaultScreen.repaint();
    } // end of switchScreen

    public void requestUpdate(String requestThis) throws RemoteException{
        if (requestThis.equals("UPDATE_ANNOUNCEMENT")){
            Object[] data = midProjectInterface.fetchAnnouncements(model.getLoginTime());
            handleIncomingData(data); 
        }
        else if (requestThis.equals("UPDATE_DATA")){
            Object[] data = midProjectInterface.fetchData();
            handleIncomingData(data); 
        }
    }
    
    public LoginController getLoginController() { return loginController; }
    public AdminController getAdminController() { return adminController; }
    public ClientController getClientController() { return clientController; }
    public List<Account> getAccountList() { return model.getAccountList(); }
    public List<Booking> getBookingList() { return model.getBookingList(); }
    public List<Booking> getGuestList() { return model.getGuestList(); }
    public List<Booking> getCheckOutList() { return model.getCheckOutList(); }
    public Account getAccount() { return model.getAccount(); }
    public MidProjectInterface getMidProjectInterface() { return midProjectInterface; }
    public Date getLoginTime() {return model.getLoginTime(); }
    public List<Announcement> getAnnouncements() { return model.getAnnouncements(); }
    public List<Room> getRoomsList() { return model.getRoomsList(); }
} // end of ApplicationController