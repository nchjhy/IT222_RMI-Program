package midproject.client.controller;

import midproject.client.view.ViewAppointmentsScreen;
import midproject.shared.Booking;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.rmi.RemoteException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.table.DefaultTableModel;

public class ViewAppointmentsController implements ActionListener {
    private final ViewAppointmentsScreen viewAppointmentsScreen;
    private final ApplicationController applicationController;

    public ViewAppointmentsController(ViewAppointmentsScreen viewAppointmentsScreen, ApplicationController applicationController) {
        this.viewAppointmentsScreen = viewAppointmentsScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        populateTable();
        setUpListeners();
        applicationController.switchScreen(viewAppointmentsScreen);
    }

    private void setUpListeners() {
        viewAppointmentsScreen.addRefreshButtonListener((new RefreshButtonListener()));
        viewAppointmentsScreen.addSearchButtonListener(new SearchButtonListener());
        viewAppointmentsScreen.getEditButton().addActionListener(this);
        viewAppointmentsScreen.getApproveButton().addActionListener(this);
        viewAppointmentsScreen.getDeclineButton().addActionListener(this);
        setUpButtonHoverEffects();
    }

    private class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try{
                applicationController.requestUpdate("UPDATE_DATA");
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        }
    }

    private class SearchButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String keyword = viewAppointmentsScreen.getSearchKeyword();
            searchBooking(keyword);
        }
    } 

    public void actionPerformed(ActionEvent e){
        if (e.getSource() == viewAppointmentsScreen.getSearchButton()){
            try{
                searchBooking(viewAppointmentsScreen.getSearchField().getText());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == viewAppointmentsScreen.getEditButton()){
            try{
                //banSelectedUser();
            } catch (Exception ex){
                ex.printStackTrace();
            }
        } else if (e.getSource() == viewAppointmentsScreen.getApproveButton()){
            DefaultTableModel tableModel = viewAppointmentsScreen.getTableModel();
            int selectedRow = viewAppointmentsScreen.getTable().getSelectedRow();

            try {
                Object[] approve = applicationController.getMidProjectInterface().approve(selectedRow);
                applicationController.handleIncomingData(approve);
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }

            tableModel.removeRow(selectedRow);
        } else if (e.getSource() == viewAppointmentsScreen.getDeclineButton()){
            DefaultTableModel tableModel = viewAppointmentsScreen.getTableModel();
            int selectedRow = viewAppointmentsScreen.getTable().getSelectedRow();
            System.out.println(selectedRow);
            try {
                Object[] decline = applicationController.getMidProjectInterface().decline(selectedRow);
                applicationController.handleIncomingData(decline);
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }

            tableModel.removeRow(selectedRow);
        }
    }

      private void searchBooking(String keyword) {
        DefaultTableModel tableModel = viewAppointmentsScreen.getTableModel();
        tableModel.setRowCount(0); // Clear existing rows in the table

        if (keyword.isEmpty()) {
            // If the search keyword is empty, refresh the table with the original list
            populateTable();
        } else {
            for (Booking booking : applicationController.getBookingList()) {
                if (booking.getEmailAddress().contains(keyword)) {
                    tableModel.addRow(new Object[]{
                              booking.getBookingID(),
                              booking.getFirstName(),
                              booking.getLastName(),
                              booking.getPhoneNumber(),
                              booking.getEmailAddress(),
                              booking.getCheck_in_date(),
                              booking.getCheck_out_date(),
                              booking.getRoomType(),
                              booking.getRoomCapacity(),
                              booking.getDaysStayed(),
                              booking.getStatus()
                      });
                  }
                  else if (booking.getFirstName().contains(keyword)){
                      tableModel.addRow(new Object[]{
                              booking.getBookingID(),
                              booking.getFirstName(),
                              booking.getLastName(),
                              booking.getPhoneNumber(),
                              booking.getEmailAddress(),
                              booking.getCheck_in_date(),
                              booking.getCheck_out_date(),
                              booking.getRoomType(),
                              booking.getRoomCapacity(),
                              booking.getDaysStayed(),
                              booking.getStatus()
                      });
                  }
                  else if (booking.getLastName().contains(keyword)){
                      tableModel.addRow(new Object[]{
                              booking.getBookingID(),
                              booking.getFirstName(),
                              booking.getLastName(),
                              booking.getPhoneNumber(),
                              booking.getEmailAddress(),
                              booking.getCheck_in_date(),
                              booking.getCheck_out_date(),
                              booking.getRoomType(),
                              booking.getRoomCapacity(),
                              booking.getDaysStayed(),
                              booking.getStatus()
                      });
                  }
            }
        }
    }

     private void populateTable(){
         clearTableModel();
         List<Booking> bookingList = applicationController.getBookingList();
         DefaultTableModel tableModel = viewAppointmentsScreen.getTableModel();

         for (int i = 0; i < bookingList.size(); i++){
             if (bookingList.get(i).getStatus().equals("pending")){
                 Object[] obj = new Object[11];
                 obj[0] = bookingList.get(i).getBookingID();
                 obj[1] = bookingList.get(i).getFirstName();
                 obj[2] = bookingList.get(i).getLastName();
                 obj[3] = bookingList.get(i).getPhoneNumber();
                 obj[4] = bookingList.get(i).getEmailAddress();
                 obj[5] = bookingList.get(i).getCheck_in_date();
                 obj[6] = bookingList.get(i).getCheck_out_date();
                 obj[7] = bookingList.get(i).getRoomType();
                 obj[8] = bookingList.get(i).getRoomCapacity();
                 obj[9] = bookingList.get(i).getDaysStayed();
                 obj[10] = bookingList.get(i).getStatus();
                 tableModel.addRow(obj);
             }
         }

         viewAppointmentsScreen.setTableModel(tableModel);
         viewAppointmentsScreen.repaint();
    }

    private void clearTableModel() {
        DefaultTableModel tableModel = viewAppointmentsScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    }

     private void setUpButtonHoverEffects() {
        // Add hover effect to Ban button
        JButton editButton = viewAppointmentsScreen.getEditButton();
        int normalWidthEditButton = editButton.getWidth();
        int normalHeightEditButton = editButton.getHeight();

        JButton approveButton = viewAppointmentsScreen.getApproveButton();
        int normalWidthApproveButton = approveButton.getWidth();
        int normalHeightApproveButton = approveButton.getHeight();

        JButton declineButton = viewAppointmentsScreen.getDeclineButton();
        int normalWidthDeclineButton = declineButton.getWidth();
        int normalHeightDeclineButton = declineButton.getHeight();

        editButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                editButton.setBackground(new Color(238,202,42)); // Dark yellow
                editButton.setSize(normalWidthEditButton + 5, normalHeightEditButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                editButton.setBackground(new Color(184,134,11)); // Light yellow
                editButton.setSize(normalWidthEditButton, normalHeightEditButton);
            }
        });

        // Add hover effect to unban booking button
        approveButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                approveButton.setBackground(new Color(37,167,124)); // Dark green
                approveButton.setSize(normalWidthApproveButton + 5, normalHeightApproveButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                approveButton.setBackground(new Color(143, 188, 143)); // Light green
                approveButton.setSize(normalWidthApproveButton, normalHeightApproveButton);
            }
        });

        // Add hover effect to delete booking button
        declineButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                declineButton.setBackground(new Color(255,82,82)); // Dark red
                declineButton.setSize(normalWidthDeclineButton + 5, normalHeightDeclineButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                declineButton.setBackground(new Color(205, 92, 92)); // Light red
                declineButton.setSize(normalWidthDeclineButton, normalHeightDeclineButton);
            }
        });
    }
} // end of ViewAppointmentsController class
