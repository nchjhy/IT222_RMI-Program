package midproject.client.controller;

import midproject.client.view.DisableDateViewScreen;
import midproject.client.view.DisableScreen;
import midproject.shared.Booking;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

public class DisableDateViewController implements ActionListener {
    private DisableDateViewScreen disableDateScreen;
    private ApplicationController applicationController;

    public DisableDateViewController(DisableDateViewScreen disableDateScreen, ApplicationController applicationController) {
        this.disableDateScreen = disableDateScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        populateTable();
        setUpListeners();
        applicationController.switchScreen(disableDateScreen);
    }

    private void setUpListeners() {
        disableDateScreen.addRefreshButtonListener(new DisableDateViewController.RefreshButtonListener());
        disableDateScreen.getAddDisableDateButton().addActionListener(this);
        disableDateScreen.getRemoveButton().addActionListener(this);
        setUpButtonHoverEffects();
    }


private class RefreshButtonListener implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            applicationController.requestUpdate("UPDATE_DATA");
        } catch (RemoteException ex) {
            ex.printStackTrace();
        }
    }
}

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == disableDateScreen.getAddDisableDateButton()){
            DisableScreen disableScreen = new DisableScreen();
            disableScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(disableDateScreen)); // when the back button is pressed
            DisableController disableController = new DisableController(disableScreen, applicationController);
            disableController.run();

        } else if (e.getSource() == disableDateScreen.getRemoveButton()) {
            try {
                removeDate();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        }
    }

    private void setUpButtonHoverEffects() {

        JButton addDisableDateButton = DisableDateViewScreen.getAddDisableDateButton();
        int normalWidthAddDisableDateButton = addDisableDateButton.getWidth();
        int normalHeightAddDisableDateButton = addDisableDateButton.getHeight();

        JButton removeButton = DisableDateViewScreen.getRemoveButton();
        int normalWidthRemoveButton = addDisableDateButton.getWidth();
        int normalHeightRemoveButton = addDisableDateButton.getHeight();

        addDisableDateButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                addDisableDateButton.setBackground(new Color(37,167,124));
                addDisableDateButton.setSize(normalWidthAddDisableDateButton + 5, normalHeightAddDisableDateButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                addDisableDateButton.setBackground(new Color(143, 188, 143));
                addDisableDateButton.setSize(normalWidthAddDisableDateButton, normalHeightAddDisableDateButton);
            }
        });

        removeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                removeButton.setBackground(new Color(255,82,82));
                removeButton.setSize(normalWidthRemoveButton + 5, normalHeightRemoveButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                removeButton.setBackground(new Color(205, 92, 92));
                removeButton.setSize(normalWidthRemoveButton, normalHeightRemoveButton);
            }
        });

    }


    private void removeDate() throws RemoteException {
        DefaultTableModel tableModel = disableDateScreen.getTableModel();
        int selectedRow = disableDateScreen.getTable().getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(disableDateScreen, "Please select a date to delete.", "No Date Selected", JOptionPane.WARNING_MESSAGE);
        }
        if (selectedRow != -1) {
            int option = JOptionPane.showConfirmDialog(disableDateScreen, "Are you sure you want to delete this Disabled Date?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                Object[] delete = applicationController.getMidProjectInterface().delete(selectedRow);
                applicationController.handleIncomingData(delete);

                tableModel.removeRow(selectedRow);
            }
        }
    }

    private void populateTable(){
        clearTableModel();
        List<Object[]> disabledDates = new ArrayList<>();
        for (Object[] dates : applicationController.getRoomsList().get(0).getDisabledDates()){
            disabledDates.add(dates);
        }
        DefaultTableModel tableModel = disableDateScreen.getTableModel();


        for (Object[] dates : disabledDates){
            Object[] obj = new Object[2];
            obj[0] = dates[0];
            obj[1] = dates[1];
            tableModel.addRow(obj);
        }

        disableDateScreen.setTableModel(tableModel);
        disableDateScreen.repaint();
    }

    private void clearTableModel() {
        DefaultTableModel tableModel = disableDateScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    }
} // end of DisableDateViewController class 