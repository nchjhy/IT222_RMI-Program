package midproject.client.controller;

import midproject.client.view.UserScreen;
import midproject.shared.Account;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.rmi.RemoteException;
import java.util.List;

public class UserController implements ActionListener {
    private final UserScreen userScreen;
    private final ApplicationController applicationController;

    public UserController(UserScreen userScreen, ApplicationController applicationController) {
        this.userScreen = userScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setupListeners();
        populateTable();
        applicationController.switchScreen(userScreen);
    }

    private void setupListeners(){
        userScreen.getSearchButton().addActionListener(this);
        userScreen.getBanButton().addActionListener(this);
        userScreen.getUnbanButton().addActionListener(this);
        userScreen.getDeleteButton().addActionListener(this);
        userScreen.getBackButton().addActionListener(this);
        setUpButtonHoverEffects();
        userScreen.addRefreshButtonListener(new RefreshButtonListener());
    }
    private class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try{
                System.out.println("Refreshing Accounts Registered table...");
                applicationController.requestUpdate("UPDATE_DATA");
                populateTable();
            } catch (RemoteException ex) {
                ex.printStackTrace();
            }
        }
    }

    public void actionPerformed(ActionEvent e){
        if (e.getSource() == userScreen.getSearchButton()){
            try{
                searchUser(userScreen.getSearchField().getText());
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        } else if (e.getSource() == userScreen.getBanButton()){
            try{
                banSelectedUser();
            } catch (Exception ex){
                ex.printStackTrace();
            }
        } else if (e.getSource() == userScreen.getUnbanButton()){
            try{
                unbanSelectedUser();
            } catch (Exception ex){
                ex.printStackTrace();
            }

        } else if (e.getSource() == userScreen.getDeleteButton()){
            try{
                deleteSelectedUser();
            } catch (Exception ex){
                ex.printStackTrace();
            }

        }
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to Ban button
        JButton banButton = userScreen.getBanButton();
        int normalWidthBanButton = banButton.getWidth();
        int normalHeightBanButton = banButton.getHeight();

        JButton unbanButton = userScreen.getUnbanButton();
        int normalWidthUnbanButton = unbanButton.getWidth();
        int normalHeightUnbanButton = unbanButton.getHeight();

        JButton deleteButton = userScreen.getDeleteButton();
        int normalWidthDeleteButton = deleteButton.getWidth();
        int normalHeightDeleteButton = deleteButton.getHeight();

        banButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                banButton.setBackground(new Color(238,202,42)); // Dark yellow
                banButton.setSize(normalWidthBanButton + 5, normalHeightBanButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                banButton.setBackground(new Color(184,134,11)); // Light yellow
                banButton.setSize(normalWidthBanButton, normalHeightBanButton);
            }
        });

        // Add hover effect to unban booking button
        unbanButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                unbanButton.setBackground(new Color(37,167,124)); // Dark green
                unbanButton.setSize(normalWidthUnbanButton + 5, normalHeightUnbanButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                unbanButton.setBackground(new Color(143, 188, 143)); // Light green
                unbanButton.setSize(normalWidthUnbanButton, normalHeightUnbanButton);
            }
        });

        // Add hover effect to delete booking button
        deleteButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                deleteButton.setBackground(new Color(255,82,82)); // Dark red
                deleteButton.setSize(normalWidthDeleteButton + 5, normalHeightDeleteButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                deleteButton.setBackground(new Color(205, 92, 92)); // Light red
                deleteButton.setSize(normalWidthDeleteButton, normalHeightDeleteButton);
            }
        });
    }

    private void populateTable(){
        clearTableModel();
        List<Account> accountList = applicationController.getAccountList();
        DefaultTableModel tableModel = userScreen.getTableModel();

        for (int i = 0; i < accountList.size(); i++){
            Object[] obj = new Object[8];
            obj[0] = accountList.get(i).getAccountNumber();
            obj[1] = accountList.get(i).getFirstName();
            obj[2] = accountList.get(i).getLastName();
            obj[3] = accountList.get(i).getPhoneNumber();
            obj[4] = accountList.get(i).getEmail();
            obj[5] = accountList.get(i).isAdmin();
            obj[6] = accountList.get(i).isBanned();
            obj[7] = accountList.get(i).isOnline();
            tableModel.addRow(obj);
        }
        userScreen.setTableModel(tableModel);
        userScreen.repaint();
    }

    private void searchUser(String keyword) {
        DefaultTableModel tableModel = userScreen.getTableModel();
        tableModel.setRowCount(0); // Clear existing rows in the table

        if (keyword.isEmpty()) {
            // If the search keyword is empty, refresh the table with the original list
            populateTable();
        } else {
            for (Account account : applicationController.getAccountList()) {
                if (account.getEmail().contains(keyword)) {
                    tableModel.addRow(new Object[]{
                            account.getAccountNumber(),
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmail(),
                            account.isAdmin(),
                            account.isBanned(),
                            account.isOnline()
                    });
                }
                else if (account.getFirstName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            account.getAccountNumber(),
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmail(),
                            account.isAdmin(),
                            account.isBanned(),
                            account.isOnline()
                    });
                }
                else if (account.getLastName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            account.getAccountNumber(),
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmail(),
                            account.isAdmin(),
                            account.isBanned(),
                            account.isOnline()
                    });
                }
            }
        }
    }

    private void banSelectedUser() throws Exception{
        // Get the selected row from the table
        int selectedRow = userScreen.getTable().getSelectedRow();
        if (selectedRow == -1) {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(userScreen, "Please select a user to ban.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) userScreen.getTable().getValueAt(selectedRow, 4);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(userScreen, "Are you sure you want to ban the user with email: " + email + "?", "Confirm Ban", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                Object[] ban = applicationController.getMidProjectInterface().ban(selectedRow);
                applicationController.handleIncomingData(ban);
                // Refresh the UI
                populateTable();
                userScreen.repaint();
            }
        }
    }

    private void unbanSelectedUser() throws Exception{
        int selectedRow = userScreen.getTable().getSelectedRow();
        if (selectedRow == -1) {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(userScreen, "Please select a user to unban.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) userScreen.getTable().getValueAt(selectedRow, 4);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(userScreen, "Are you sure you want to unban the user with email: " + email + "?", "Confirm Unban", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                Object[] unban = applicationController.getMidProjectInterface().unban(selectedRow);
                applicationController.handleIncomingData(unban);
                // Refresh the UI
                populateTable();
                userScreen.repaint();
            }
        }
    }

    private void deleteSelectedUser() throws Exception{
        DefaultTableModel tableModel = userScreen.getTableModel();
        int selectedRow = userScreen.getTable().getSelectedRow();
        if (selectedRow == -1) {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(userScreen, "Please select a user to delete.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) userScreen.getTable().getValueAt(selectedRow, 4);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(userScreen, "Are you sure you want to delete the user with email: " + email + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                Object[] delete = applicationController.getMidProjectInterface().delete(selectedRow);
                applicationController.handleIncomingData(delete);

                tableModel.removeRow(selectedRow);
            }
        }
    }

    private void clearTableModel() {
        DefaultTableModel tableModel = userScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    }
} // end of UserController class 




