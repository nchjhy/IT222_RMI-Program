package midproject.client.controller;

import midproject.client.view.CheckOutScreen;
import midproject.client.view.GuestScreen;
import midproject.shared.Booking;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.List;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;


public class GuestController implements ActionListener {
    private final GuestScreen guestScreen;
    private final ApplicationController applicationController;

    public GuestController(GuestScreen guestScreen, ApplicationController applicationController) {
        this.guestScreen = guestScreen;
        this.applicationController = applicationController;
    }
    public void run() {
        addListeners();
        populateTable();
        applicationController.switchScreen(guestScreen);
    } // end of run

    private void addListeners() {
        // Attach ActionListener to the search button
        guestScreen.addSearchButtonListener(this);
        guestScreen.addCheckOutButtonListener(this);
        guestScreen.addViewCheckOutButtonListener(this);
        setUpButtonHoverEffects();
    } // end of addListeners

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == guestScreen.getSearchButton()) {
            // Perform search based on the entered keyword
            search(guestScreen.getSearchField().getText());
        } else if (e.getSource() == guestScreen.getCheckoutButton()) {
            try {
                checkOut();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == guestScreen.getViewCheckOutButton()) {
            CheckOutScreen checkOutScreen = new CheckOutScreen();
            checkOutScreen.getBackButton().addActionListener(action -> applicationController.switchScreen(guestScreen)); // when the back button is pressed
            CheckOutController checkOutController = new CheckOutController(checkOutScreen, applicationController);
            checkOutController.run();
        }
    }

    private void setUpButtonHoverEffects() {

        // Add hover effect to check out button
        JButton checkOutButton = guestScreen.getCheckoutButton();
        int normalWidthCheckOutButton = checkOutButton.getWidth();
        int normalHeightCheckOutButton = checkOutButton.getHeight();

        JButton viewCheckOutButton = guestScreen.getViewCheckOutButton();
        int normalWidthCancelBookingButton = viewCheckOutButton.getWidth();
        int normalHeightCancelBookingButton = viewCheckOutButton.getHeight();

        checkOutButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                checkOutButton.setBackground(new Color(255,82,82)); // Dark red
                checkOutButton.setSize(normalWidthCheckOutButton + 5, normalHeightCheckOutButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                checkOutButton.setBackground(new Color(205, 92, 92)); // Light red
                checkOutButton.setSize(normalWidthCheckOutButton, normalHeightCheckOutButton);
            }
        });

        // Add hover effect to view check out button
        viewCheckOutButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                viewCheckOutButton.setBackground(new Color(37,167,124)); // Dark green
                viewCheckOutButton.setSize(normalWidthCancelBookingButton + 5, normalHeightCancelBookingButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                viewCheckOutButton.setBackground(new Color(143, 188, 143)); // Light green
                viewCheckOutButton.setSize(normalWidthCancelBookingButton, normalHeightCancelBookingButton);
            }
        });
    } // end of setUpButtonHoverEffects

     private void populateTable(){
        clearTableModel();
        List<Booking> accountList = applicationController.getGuestList();
        if (accountList != null) {
            DefaultTableModel tableModel = guestScreen.getTableModel();
    
            for (int i = 0; i < accountList.size(); i++){
                Object[] obj = new Object[9];
                obj[0] = accountList.get(i).getBookingID();
                obj[1] = accountList.get(i).getFirstName();
                obj[2] = accountList.get(i).getLastName();
                obj[3] = accountList.get(i).getPhoneNumber();
                obj[4] = accountList.get(i).getEmailAddress();
                obj[5] = accountList.get(i).getCheck_in_date();
                obj[6] = accountList.get(i).getCheck_out_date();
                obj[7] = accountList.get(i).getRoomType();
                obj[8] = accountList.get(i).getRoomCapacity();
                tableModel.addRow(obj);
            }
            guestScreen.setTableModel(tableModel);
        } else {
            JOptionPane.showMessageDialog(guestScreen, "No bookings available.", "No Bookings", JOptionPane.INFORMATION_MESSAGE);
        }
    } // end of populateTable

    private void search(String keyword) {
        DefaultTableModel tableModel = guestScreen.getTableModel();
        tableModel.setRowCount(0); // Clear existing rows in the table

        if (keyword.isEmpty()) {
            // If the search keyword is empty, refresh the table with the original list
            populateTable();
        } else {
            for (Booking account : applicationController.getGuestList()) {
                if (account.getEmailAddress().contains(keyword)) {
                    tableModel.addRow(new Object[]{
                            account.getBookingID(),
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmailAddress(),
                            account.getCheck_in_date(),
                            account.getCheck_out_date(),
                            account.getRoomType(),
                            account.getRoomCapacity()
                    });
                }
                else if (account.getFirstName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            account.getBookingID(),
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmailAddress(),
                            account.getCheck_in_date(),
                            account.getCheck_out_date(),
                            account.getRoomType(),
                            account.getRoomCapacity()
                    });
                }
                else if (account.getLastName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            account.getBookingID(),
                            account.getFirstName(),
                            account.getLastName(),
                            account.getPhoneNumber(),
                            account.getEmailAddress(),
                            account.getCheck_in_date(),
                            account.getCheck_out_date(),
                            account.getRoomType(),
                            account.getRoomCapacity()
                    });
                }
            }
        }
    } // end of search

    private void checkOut() throws RemoteException {
        DefaultTableModel tableModel = guestScreen.getTableModel();
        int selectedRow = guestScreen.getTable().getSelectedRow();
        if (selectedRow == -1) {
            // No row selected, show a message to select a user
            JOptionPane.showMessageDialog(guestScreen, "Please select a user to check out.", "No User Selected", JOptionPane.WARNING_MESSAGE);
        }
        if (selectedRow != -1) {
            // Get the email from the selected row
            String email = (String) guestScreen.getTable().getValueAt(selectedRow, 4);
            // Show confirmation dialog
            int option = JOptionPane.showConfirmDialog(guestScreen, "Are you sure you want to checkout the user with email: " + email + "?", "Confirm Check Out", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                // Fields to get input values
                String bookingID = applicationController.getGuestList().get(selectedRow).getBookingID();
                String firstName = applicationController.getGuestList().get(selectedRow).getFirstName();
                String lastName = applicationController.getGuestList().get(selectedRow).getLastName();
                String phoneNumber = applicationController.getGuestList().get(selectedRow).getPhoneNumber();
                String emailAddress = applicationController.getGuestList().get(selectedRow).getEmailAddress();
                String checkInDate = applicationController.getGuestList().get(selectedRow).getCheck_in_date();
                String checkOutDate = applicationController.getGuestList().get(selectedRow).getCheck_out_date();
                String roomType = applicationController.getGuestList().get(selectedRow).getRoomType();
                String roomCapacity = applicationController.getGuestList().get(selectedRow).getRoomCapacity();
                String uniqueID = applicationController.getGuestList().get(selectedRow).getUniqueID();

                Object[] checkout = applicationController.getMidProjectInterface().checkout(bookingID, firstName, lastName, phoneNumber, emailAddress, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID);
                applicationController.handleIncomingData(checkout);
                tableModel.removeRow(selectedRow);

                populateTable();
                guestScreen.repaint();
            }
        }
    } // end of checkout

    private void clearTableModel() {
        DefaultTableModel tableModel = guestScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    } // end of clearTableModel

} // end of GuestController

