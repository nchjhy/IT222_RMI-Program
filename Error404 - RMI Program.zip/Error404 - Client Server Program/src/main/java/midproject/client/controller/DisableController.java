package midproject.client.controller;

import midproject.client.view.DisableScreen;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DisableController implements ActionListener {
    private DisableScreen disableDatesScreen;
    private ApplicationController applicationController;

    public DisableController(DisableScreen disableDatesScreen, ApplicationController applicationController) {
        this.disableDatesScreen = disableDatesScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setUpListeners();
        applicationController.switchScreen(disableDatesScreen);
    }

    private void setUpListeners() {
        disableDatesScreen.getDisableButton().addActionListener(this);
        disableDatesScreen.getClearButton().addActionListener(this);
        setUpButtonHoverEffects();
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == disableDatesScreen.getDisableButton()) {
            try {
                disable();
            } catch (RemoteException ex) {
                throw new RuntimeException(ex);
            }
        } else if (e.getSource() == disableDatesScreen.getClearButton()) {
            clear();
        }
    }

    private void setUpButtonHoverEffects() {
        // Add hover effect to clear button
        JButton clearButton = disableDatesScreen.getClearButton();
        int normalWidthClearButton = clearButton.getWidth();
        int normalHeightClearButton = clearButton.getHeight();
        JButton disableButton = disableDatesScreen.getDisableButton();
        int normalWidthSubmitButton = disableButton.getWidth();
        int normalHeightSubmitButton = disableButton.getHeight();

        clearButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                clearButton.setBackground(new Color(112, 128, 144)); // Dark grey
                clearButton.setSize(normalWidthClearButton + 5, normalHeightClearButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                clearButton.setBackground(new Color(192, 192, 192)); // Light grey
                clearButton.setSize(normalWidthClearButton, normalHeightClearButton);
            }
        });

        // Add hover effect to submit button
        disableButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                disableButton.setBackground(new Color(37,167,124)); // Dark green
                disableButton.setSize(normalWidthSubmitButton + 5, normalHeightSubmitButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                disableButton.setBackground(new Color(143, 188, 143)); // Light green
                disableButton.setSize(normalWidthSubmitButton, normalHeightSubmitButton);
            }
        });
    }

    private void disable() throws RemoteException{
        String reason = (String) disableDatesScreen.getReasonTypeComboBox().getSelectedItem();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        // Check if the date choosers return non-null values
        Date from = disableDatesScreen.getFromDateChooser().getDate();
        Date to = disableDatesScreen.getToDateChooser().getDate();

        // Check if either of the dates are null before formatting
        if (from != null && to != null) {
            String start = dateFormat.format(from);
            String end = dateFormat.format(to);

            Object[] disable = applicationController.getMidProjectInterface().disableDates(start, end, reason);
            applicationController.handleIncomingData(disable);
            clear();
        } else{
            // Handle the case when either check-in or check-out date is null
            JOptionPane.showMessageDialog(null,"Fields must not be empty");
        }
    }

    private void clear() {
        disableDatesScreen.getFromDateChooser().setDate(null);
        disableDatesScreen.getToDateChooser().setDate(null);
        disableDatesScreen.getReasonTypeComboBox().setSelectedItem("Select");
    }

}
