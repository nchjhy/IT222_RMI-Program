package midproject.client.controller;

import midproject.client.view.ProfileScreen;

public class ProfileController {
    private ProfileScreen profileScreen;
    private ApplicationController applicationController;

    public ProfileController(ProfileScreen profileScreen, ApplicationController applicationController) {
        this.profileScreen = profileScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        applicationController.switchScreen(profileScreen);
    }
} // end of ProfileController class 
