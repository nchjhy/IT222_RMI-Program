package midproject.client.controller;

import midproject.client.view.LoginScreen;
import midproject.client.view.RegisterScreen;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.io.Serializable;
import java.rmi.RemoteException;
import javax.swing.JButton;

public class LoginController implements ActionListener, Serializable {
    private final ApplicationController applicationController;
    private final LoginScreen loginScreen;
    private final RegisterScreen registerScreen = new RegisterScreen();

    public LoginController(LoginScreen loginScreen, ApplicationController applicationController) {
        this.loginScreen = loginScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        setupListeners();
        applicationController.switchScreen(loginScreen);
    } // end of run

    private void setupListeners() {
        loginScreen.getLoginButton().addActionListener(this);
        loginScreen.getRegisterButton().addActionListener(this);
        loginScreen.getShowPassword().addActionListener(this);
        setUpButtonHoverEffects();
    } // end of setupListeners

    @Override
public void actionPerformed(ActionEvent e) {
    if (e.getSource() == loginScreen.getLoginButton()) {
        try {
            loginAccount();
        } catch (RemoteException ex) {
            System.out.println(ex.getMessage());
        }
    } else if (e.getSource() == loginScreen.getRegisterButton()) {
        RegisterController registerController = new RegisterController(registerScreen, applicationController);
        registerController.run();
        applicationController.switchScreen(registerScreen);
    } else if (e.getSource() == loginScreen.getShowPassword())
        showPassword();
}

    private void setUpButtonHoverEffects() {
        JButton loginButton = loginScreen.getLoginButton();
        int normalWidthLoginButton = loginButton.getWidth();
        int normalHeightLoginButton = loginButton.getHeight();

        JButton registerButton = loginScreen.getRegisterButton();
        int normalWidthRegisterButton = registerButton.getWidth();
        int normalHeightRegisterButton = registerButton.getHeight();

        // Add hover effect to login button
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(41,134,204)); // Dark blue
                loginButton.setSize(normalWidthLoginButton + 5, normalHeightLoginButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(new Color(48, 114, 163)); // Light blue
                loginButton.setSize(normalWidthLoginButton, normalHeightLoginButton);
            }
        });

        // Add hover effect to register button
        registerButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                registerButton.setBackground(new Color(112, 128, 144)); // Dark grey
                registerButton.setSize(normalWidthRegisterButton + 5, normalHeightRegisterButton + 5);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                registerButton.setBackground(new Color(192, 192, 192)); // Light grey
                registerButton.setSize(normalWidthRegisterButton, normalHeightRegisterButton);
            }
        });
    }

    private void loginAccount() throws RemoteException {
        String emailInput = loginScreen.getEmailField().getText().toLowerCase().trim();
        String passwordInput = loginScreen.getPasswordField().getText().trim();
        //Object[] requestPackage = new Object[] {emailInput, passwordInput};
        Object[] login = applicationController.getMidProjectInterface().login(emailInput, passwordInput);
        applicationController.handleIncomingData(login);
        clear();
    } // end of loginAccount

    private void showPassword() {
        if (loginScreen.getShowPassword().isSelected()) {
            loginScreen.getPasswordField().setEchoChar((char) 0);
        } else {
            loginScreen.getPasswordField().setEchoChar('•');
        }
    } // end of showPassword

    public LoginScreen getLoginScreen() {
        return loginScreen;
    }

    private void clear(){
        loginScreen.getEmailField().setText(null);
        loginScreen.getPasswordField().setText(null);
    }
} // end of LoginController
