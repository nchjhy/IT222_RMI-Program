package midproject.client.controller;

import midproject.client.view.BookingHistoryScreen;
import midproject.shared.Booking;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.RemoteException;
import java.util.List;

public class BookingHistoryController implements ActionListener {
    private final BookingHistoryScreen bookingHistoryScreen;
    private final ApplicationController applicationController;

    public BookingHistoryController(BookingHistoryScreen bookingHistoryScreen, ApplicationController applicationController) {
        this.bookingHistoryScreen = bookingHistoryScreen;
        this.applicationController = applicationController;
    }

    public void run() {
        addListeners();
        populateTable();
        applicationController.switchScreen(bookingHistoryScreen);
    } // end of run method

    private void addListeners() {
        bookingHistoryScreen.addSearchButtonListener(this);
        bookingHistoryScreen.addRefreshButtonListener(new RefreshButtonListener());
    } // end of addListeners

    private class RefreshButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                applicationController.requestUpdate("UPDATE_DATA");
                populateTable();
            } catch (RemoteException ex) {
                ex.printStackTrace(); 
            }
        }
    }
    


    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == bookingHistoryScreen.getSearchButton()) {
            searchUser(bookingHistoryScreen.getSearchField().getText());
        }
    }

    private void populateTable(){
        clearTableModel();
        try {
            applicationController.requestUpdate("UPDATE_DATA");
        } catch (RemoteException e) {
            throw new RuntimeException(e);
        }
        List<Booking> bookingList = applicationController.getBookingList();
        DefaultTableModel tableModel = bookingHistoryScreen.getTableModel();

        if (applicationController.getAccount().isAdmin()){
            for (int i = 0; i < bookingList.size(); i++){
                Object[] obj = new Object[11];
                obj[0] = bookingList.get(i).getBookingID();
                obj[1] = bookingList.get(i).getFirstName();
                obj[2] = bookingList.get(i).getLastName();
                obj[3] = bookingList.get(i).getPhoneNumber();
                obj[4] = bookingList.get(i).getEmailAddress();
                obj[5] = bookingList.get(i).getCheck_in_date();
                obj[6] = bookingList.get(i).getCheck_out_date();
                obj[7] = bookingList.get(i).getRoomType();
                obj[8] = bookingList.get(i).getRoomCapacity();
                obj[9] = bookingList.get(i).getDaysStayed();
                obj[10] = bookingList.get(i).getStatus();
                tableModel.addRow(obj);
            }
        }
        if (!applicationController.getAccount().isAdmin()){
            for (int i = 0; i < bookingList.size(); i++){
                if (bookingList.get(i).getEmailAddress().equals(applicationController.getAccount().getEmail())){
                    Object[] obj = new Object[11];
                    obj[0] = bookingList.get(i).getBookingID();
                    obj[1] = bookingList.get(i).getFirstName();
                    obj[2] = bookingList.get(i).getLastName();
                    obj[3] = bookingList.get(i).getPhoneNumber();
                    obj[4] = bookingList.get(i).getEmailAddress();
                    obj[5] = bookingList.get(i).getCheck_in_date();
                    obj[6] = bookingList.get(i).getCheck_out_date();
                    obj[7] = bookingList.get(i).getRoomType();
                    obj[8] = bookingList.get(i).getRoomCapacity();
                    obj[9] = bookingList.get(i).getDaysStayed();
                    obj[10] = bookingList.get(i).getStatus();
                    tableModel.addRow(obj);
                }
            }
        }

        bookingHistoryScreen.setTableModel(tableModel);
        bookingHistoryScreen.repaint();
    }

    private void searchUser(String keyword) {
        DefaultTableModel tableModel = bookingHistoryScreen.getTableModel();
        tableModel.setRowCount(0); // Clear existing rows in the table

        if (keyword.isEmpty()) {
            // If the search keyword is empty, refresh the table with the original list
            populateTable();
        } else {
            for (Booking booking : applicationController.getBookingList()) {
                if (booking.getEmailAddress().contains(keyword)) {
                    tableModel.addRow(new Object[]{
                            booking.getBookingID(),
                            booking.getFirstName(),
                            booking.getLastName(),
                            booking.getPhoneNumber(),
                            booking.getEmailAddress(),
                            booking.getCheck_in_date(),
                            booking.getCheck_out_date(),
                            booking.getRoomType(),
                            booking.getRoomCapacity(),
                            booking.getDaysStayed(),
                            booking.getStatus()
                    });
                }
                else if (booking.getFirstName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            booking.getBookingID(),
                            booking.getFirstName(),
                            booking.getLastName(),
                            booking.getPhoneNumber(),
                            booking.getEmailAddress(),
                            booking.getCheck_in_date(),
                            booking.getCheck_out_date(),
                            booking.getRoomType(),
                            booking.getRoomCapacity(),
                            booking.getDaysStayed(),
                            booking.getStatus()
                    });
                }
                else if (booking.getLastName().contains(keyword)){
                    tableModel.addRow(new Object[]{
                            booking.getBookingID(),
                            booking.getFirstName(),
                            booking.getLastName(),
                            booking.getPhoneNumber(),
                            booking.getEmailAddress(),
                            booking.getCheck_in_date(),
                            booking.getCheck_out_date(),
                            booking.getRoomType(),
                            booking.getRoomCapacity(),
                            booking.getDaysStayed(),
                            booking.getStatus()
                    });
                }
            }
        }
    }

    private void clearTableModel() {
        DefaultTableModel tableModel = bookingHistoryScreen.getTableModel();
        while (tableModel.getRowCount() > 0) {
            tableModel.removeRow(0);
        }
    } // end of clearTableModel

} // end of BookingHistoryController class
