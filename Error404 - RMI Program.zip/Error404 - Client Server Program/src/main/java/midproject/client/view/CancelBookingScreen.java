package midproject.client.view;

import javax.swing.*;
import java.awt.*;

public class CancelBookingScreen extends Screen {
    private JTextField bookingIDField;
    private JButton clearButton, cancelBookingButton;

    public CancelBookingScreen() {
        getBackButton().setVisible(true);

        initializeComponents();
        setLayout(new BorderLayout());
        getBackButton().setVisible(true);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel titleLabel = new JLabel("CANCEL BOOKING");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(590, 70, 500, 50);
        mainPanel.add(titleLabel);

        JLabel bookingIDLabel = new JLabel("Booking ID: ");
        bookingIDLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        bookingIDLabel.setBounds(620, 200, 200, 65);
        bookingIDField.setBounds(750, 210, 200, 40);

        clearButton.setBounds(680, 640, 90, 40);
        clearButton.setBackground(new Color(192, 192, 192));
        clearButton.setFont(new Font("Tahoma", Font.BOLD, 12));

        cancelBookingButton.setBounds(830, 640, 130, 40);
        cancelBookingButton.setBackground(new Color(205, 92, 92));
        cancelBookingButton.setFont(new Font("Tahoma", Font.BOLD, 12));

        mainPanel.add(bookingIDLabel);
        mainPanel.add(bookingIDField);
        mainPanel.add(clearButton);
        mainPanel.add(cancelBookingButton);

        add(mainPanel);
    }

    private void initializeComponents() {
        bookingIDField = new JTextField();
        clearButton = new JButton("Clear");
        cancelBookingButton = new JButton("Cancel Booking");

    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JButton getCancelBookingButton() {
        return cancelBookingButton;
    }

    public JTextField getBookingIDField() { return bookingIDField; }

} // end of CancelBookingScreen class
