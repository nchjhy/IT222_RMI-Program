package midproject.client.view;

import javax.swing.*;

public enum ScreenType {

    LOGIN_SCREEN(0, new LoginScreen()),
    REGISTER_SCREEN(1, new RegisterScreen()),
    ADMINHOME_SCREEN(2, new AdminHomeScreen()),
    CLIENTHOME_SCREEN(3, new ClientHomeScreen()),
    CHECKIN_SCREEN(4, new CheckinScreen()),
    VIEW_APPOINTMENTS_SCREEN(5, new ViewAppointmentsScreen()),
    PROFILE_SCREEN(6, new ProfileScreen()),
    ANNOUNCEMENT_SCREEN(7, new AnnouncementScreen()),
    GUEST_SCREEN(8, new GuestScreen()),
    CANCELBOOKING_SCREEN(10, new CancelBookingScreen()),
    BOOKINGHISTORY_SCREEN(11, new BookingHistoryScreen()),
    USER_SCREEN(13, new UserScreen()),
    BOOKING_SCREEN(14, new BookingScreen()),
    ADDROOM_SCREEN(15, new AddRoomScreen());

    private final int value; // Value of screen
    private final JPanel screen;

    // Constructor
    ScreenType(int value, JPanel screen) {
        this.value = value;
        this.screen = screen;
    }

    // Getter
    public int getValue() {
        return value;
    }

    public JPanel getScreen() {
        return screen;
    }
} // end of ScreenType class 
