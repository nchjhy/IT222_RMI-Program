package midproject.client.view;

import javax.swing.*;
import com.toedter.calendar.JDateChooser;
import java.awt.*;

public class BookingScreen extends Screen {
    private JTextField firstNameField, lastNameField, phoneField, emailField, roomCapacityField;
    private JButton submitButton, clearButton;
    private JComboBox<String> roomTypeComboBox;
    private JDateChooser checkOutDateChooser;
    private JDateChooser checkInDateChooser;
    private JLabel backgroundPhoto = new JLabel(new ImageIcon("src/main/java/midproject/utilities/bgbooking.png"));


    public BookingScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel(){
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        backgroundPhoto.setBounds(10, 175, 1560, 1230);
        mainPanel.add(backgroundPhoto);

        JLabel headerLabel = new JLabel("BOOKING");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(685, 100, 300, 50);

        JLabel firstNameLabel = new JLabel("First Name: ");
        firstNameLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(firstNameLabel);
        firstNameLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,250,150,30);

        JLabel lastNameLabel = new JLabel("Last Name: ");
        lastNameLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(lastNameLabel);
        lastNameLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,325,150,30);

        JLabel phoneLabel = new JLabel("Phone: ");
        phoneLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(phoneLabel);
        phoneLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,400,150,30);

        JLabel emailLabel = new JLabel("Email: ");
        emailLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(emailLabel);
        emailLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,475,150,30);

        JLabel checkInLabel = new JLabel("Check-In Date: ");
        checkInLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(checkInLabel);
        checkInLabel.setBounds(DefaultScreen.WIDTH / 2 + 100,400,175,30);

        checkInDateChooser = new JDateChooser();
        checkInDateChooser.setBounds( 1100,400,225,30);
        mainPanel.add(checkInDateChooser);

        JLabel checkOutLabel = new JLabel("Check-Out Date: ");
        checkOutLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(checkOutLabel);
        checkOutLabel.setBounds(DefaultScreen.WIDTH / 2 + 100,475,175,30);

        checkOutDateChooser = new JDateChooser();
        checkOutDateChooser.setBounds(1100,475,225,30);
        mainPanel.add(checkOutDateChooser);

        JLabel roomTypeLabel = new JLabel("Room Type: ");
        roomTypeLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(roomTypeLabel);
        roomTypeLabel.setBounds(DefaultScreen.WIDTH / 2 + 100,250,175,30);

        JLabel roomCapacityLabel = new JLabel("Room Capacity: ");
        roomCapacityLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
        mainPanel.add(roomCapacityLabel);
        roomCapacityLabel.setBounds(DefaultScreen.WIDTH / 2 + 100, 325, 175, 30);

        firstNameField = new JTextField();
        mainPanel.add(firstNameField);
        firstNameField.setBounds(DefaultScreen.WIDTH / 2 - 300,250,175,30);

        lastNameField = new JTextField();
        mainPanel.add(lastNameField);
        lastNameField.setBounds(DefaultScreen.WIDTH / 2 - 300,325,175,30);

        phoneField = new JTextField();
        mainPanel.add(phoneField);
        phoneField.setBounds(DefaultScreen.WIDTH / 2 - 300,400,175,30);

        emailField = new JTextField();
        mainPanel.add(emailField);
        emailField.setBounds(DefaultScreen.WIDTH / 2 - 300,475,175,30);

        roomTypeComboBox = new JComboBox<>();
        mainPanel.add(roomTypeComboBox);
        roomTypeComboBox.setBounds(DefaultScreen.WIDTH / 2 + 300,250,225,30);

        roomCapacityField = new JTextField();
        roomCapacityField.setEnabled(false);
        mainPanel.add(roomCapacityField);
        roomCapacityField.setBounds(DefaultScreen.WIDTH / 2 + 300, 325, 225, 30);

        submitButton = new JButton("Submit");
        mainPanel.add(submitButton);
        submitButton.setBounds(625, 563, 100, 40);
        submitButton.setBackground(new Color(143, 188, 143));

        clearButton = new JButton("Clear");
        mainPanel.add(clearButton);
        clearButton.setBounds(850, 563, 100, 40);
        clearButton.setBackground(new Color(192, 192, 192));

        return mainPanel;
    }


//    private String[] getRoomTypeOptions() {
//        return new String[]{"Choose Room Type", "Pair Room", "Family Room", "Large Room"};
//    }

    public JTextField getFirstNameField() {
        return firstNameField;
    }
    public JTextField getLastNameField() {
        return lastNameField;
    }
    public JTextField getPhoneField() {
        return phoneField;
    }
    public JTextField getEmailField() {
        return emailField;
    }
    public JButton getSubmitButton() {
        return submitButton;
    }
    public JButton getClearButton() {
        return clearButton;
    }


    public JDateChooser getCheckInChooser() { return checkInDateChooser; }

    public JDateChooser getCheckOutChooser () {
        return checkOutDateChooser;
    }

    public JComboBox<String> getRoomTypeComboBox() {
        return roomTypeComboBox; }

    public JTextField getRoomCapacityField() {
        return roomCapacityField;
    }
} // end of BookingScreen class 
