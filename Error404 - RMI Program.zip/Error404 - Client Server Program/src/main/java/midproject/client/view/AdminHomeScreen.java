package midproject.client.view;

import javax.swing.*;
import java.awt.*;

public class AdminHomeScreen extends Screen {
    private JPanel dashboardPanel = new JPanel();
    private JLabel welcomeLabel = new JLabel("Welcome to Error 404 Transients");
    private JLabel backgroundPhoto = new JLabel(new ImageIcon("src/main/java/midproject/utilities/bgadmin.png"));
    private JLabel backgroundLabel = new JLabel(new ImageIcon("src/main/java/midproject/utilities/logobg.png"));
    private JButton appointmentButton = new JButton("Book Now", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/check-in.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton viewAppointmentButton = new JButton("<html>View<br/>Bookings</html>", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/room.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton profileButton = new JButton("Your Profile", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/user.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton annoucementButton = new JButton("Announce", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/announce.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton guestButton = new JButton("Guest", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/guest.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton bookingHistoryButton = new JButton("<html>Booking<br/>History</html>", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/bhistory.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton logoutButton = new JButton("Logout", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/logout.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT)));
    private JButton userButton = new JButton("<html>Accounts<br/>Registered<html>", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/users.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton manageButton = new JButton("Manage", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/manage.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton bookNowButton = new JButton("Check-in", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/booking.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private static final Font FONT = new Font("Tahoma", Font.BOLD, 25);

    public AdminHomeScreen() {
        getBackToHomeButton().setVisible(true);
        setBackground(new Color(113, 146, 172));

        dashboardPanel.setBounds(430, 150, 1090, 650);
        dashboardPanel.setBackground(new Color(234,235,254));
        dashboardPanel.setLayout(null);
        add(dashboardPanel);

        backgroundLabel.setBounds(130, 150, 250, 300);
        add(backgroundLabel);

        backgroundPhoto.setBounds(70, 150, 410, 650);
        add(backgroundPhoto);


        welcomeLabel.setBounds(150, 50, 1000, 100);
        welcomeLabel.setFont(new Font("Georgia", Font.BOLD, 50));
        welcomeLabel.setForeground(Color.WHITE);
        add(welcomeLabel);

        annoucementButton.setBackground(new Color(30, 75, 135));
        annoucementButton.setForeground(Color.WHITE);
        annoucementButton.setFont(FONT);
        annoucementButton.setBorder(null);
        annoucementButton.setBounds(50, 40,  250, 120);
        add(annoucementButton);
        dashboardPanel.add(annoucementButton);

        appointmentButton.setBackground(new Color(30, 75, 135));
        appointmentButton.setForeground(Color.WHITE);
        appointmentButton.setFont(FONT);
        appointmentButton.setBorder(null);
        appointmentButton.setBounds(50, 230, 250, 120);
        add( appointmentButton);
        dashboardPanel.add(appointmentButton);

        bookingHistoryButton.setBackground(new Color(30, 75, 135));
        bookingHistoryButton.setForeground(Color.WHITE);
        bookingHistoryButton.setFont(FONT);
        bookingHistoryButton.setBorder(null);
        bookingHistoryButton.setBounds(50, 420,  250, 120);
        add(bookingHistoryButton);
        dashboardPanel.add(bookingHistoryButton);

        guestButton.setBackground(new Color(30, 75, 135));
        guestButton.setForeground(Color.WHITE);
        guestButton.setFont(FONT);
        guestButton.setBorder(null);
        guestButton.setBounds(430, 40,  250, 120);
        add(guestButton);
        dashboardPanel.add(guestButton);

        bookNowButton.setBackground(new Color(30, 75, 135));
        bookNowButton.setForeground(Color.WHITE);
        bookNowButton.setFont(FONT);
        bookNowButton.setBorder(null);
        bookNowButton.setBounds(430, 230, 250, 120);
        add(bookNowButton);
        dashboardPanel.add(bookNowButton);

        profileButton.setBackground(new Color(30, 75, 135));
        profileButton.setForeground(Color.WHITE);
        profileButton.setFont(FONT);
        profileButton.setBorder(null);
        profileButton.setBounds(800, 420,  250, 120);
        add(profileButton);
        dashboardPanel.add(profileButton);

        userButton.setBackground(new Color(30, 75, 135));
        userButton.setForeground(Color.WHITE);
        userButton.setFont(FONT);
        userButton.setBorder(null);
        userButton.setBounds(800,40, 250, 120);
        add(userButton);
        dashboardPanel.add(userButton);

        viewAppointmentButton.setBackground(new Color(30, 75, 135));
        viewAppointmentButton.setForeground(Color.WHITE);
        viewAppointmentButton.setFont(FONT);
        viewAppointmentButton.setBorder(null);
        viewAppointmentButton.setBounds( 800, 230,  250, 120);
        add(viewAppointmentButton);
        dashboardPanel.add(viewAppointmentButton);

        manageButton.setBackground(new Color(30, 75, 135));
        manageButton.setForeground(Color.WHITE);
        manageButton.setFont(FONT);
        manageButton.setBorder(null);
        manageButton.setBounds(430, 420, 250, 120);
        add(manageButton); 
        dashboardPanel.add(manageButton);

        logoutButton.setBackground(new Color(30, 75, 135));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Tahoma", Font.BOLD, 15));
        logoutButton.setBorder(null);
        logoutButton.setBackground(new Color(205, 92, 92));
        logoutButton.setBounds(500, 585, 120, 40);
        add(logoutButton);
        dashboardPanel.add(logoutButton);


    }

    public JLabel getWelcomeLabel() { return welcomeLabel; }
    public JLabel getBackgroundLabel() {return backgroundLabel;}
    public JButton getAppointmentButton() { return appointmentButton; }
    public JButton getViewAppointmentButton() { return viewAppointmentButton; }
    public JButton getProfileButton() { return profileButton; }
    public JButton getBookingHistoryButton() { return bookingHistoryButton; }
    public JButton getAnnouncementButton() { return annoucementButton; }
    public JButton getGuestButton() { return guestButton; }
    public JButton getLogoutButton(){ return logoutButton; }
    public JButton getUserButton(){ return userButton; }
    public JButton getBookNowButton() { return bookNowButton; }
    public JButton getManageButton() { return manageButton; }

} // end of AdminHomeScreen class 
