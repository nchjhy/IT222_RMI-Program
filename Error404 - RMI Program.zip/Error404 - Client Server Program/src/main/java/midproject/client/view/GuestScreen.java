package midproject.client.view;

import midproject.client.controller.GuestController;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class GuestScreen extends Screen {
    private JTextField searchField;
    private JButton searchButton;
    private JButton checkOutButton;
    private JButton viewCheckOutButton;
    private JTable table;
    private DefaultTableModel tableModel;
    private final JButton refresh = new JButton(new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/refresh.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT)));

    public GuestScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        refresh.setBounds(1510, 21, 20, 20);
        add(refresh);

        JLabel headerLabel = new JLabel("GUESTS");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(DefaultScreen.WIDTH / 2 - 50, 10, 100, 30);

        JLabel searchLabel = new JLabel("Search: ");
        mainPanel.add(searchLabel);
        searchLabel.setBounds(10, 20, 60, 20);

        searchField = new JTextField(15);
        mainPanel.add(searchField);
        searchField.setBounds(80, 15, 120, 30);

        searchButton = new JButton("Search");
        mainPanel.add(searchButton);
        searchButton.setBounds(210, 15, 80, 30);

        checkOutButton = new JButton("Check Out");
        mainPanel.add(checkOutButton);
        checkOutButton.setBounds(DefaultScreen.WIDTH / 2 - 250, 800, 200, 40);
        checkOutButton.setBackground(new Color(205, 92, 92));
        checkOutButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        viewCheckOutButton = new JButton("View Check Out");
        mainPanel.add(viewCheckOutButton);
        viewCheckOutButton.setBounds(DefaultScreen.WIDTH / 2 + 75, 800, 200, 40);
        viewCheckOutButton.setBackground(new Color(143, 188, 143));
        viewCheckOutButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        // Create the table
        String[] columnNames = {"Booking ID", "First Name", "Last Name", "Phone Number", "Email Address", "Check-in Date", "Expected Check-out Date", "Room Type", "Room Capacity"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane);
        scrollPane.setBounds(10, 50, DefaultScreen.WIDTH - 20, DefaultScreen.HEIGHT - 180);

        return mainPanel;
    }

    public void addViewCheckOutButtonListener(GuestController guestController) {
        viewCheckOutButton.addActionListener(guestController);
    }


    public void addSearchButtonListener(GuestController guestController) {
        searchButton.addActionListener(guestController);
    }

    // public void addViewCheckOutButtonListener(CheckOutController checkOutController) {
    //     viewCheckOutButton.addActionListener(checkOutController);
    // }

    public void addCheckOutButtonListener(GuestController guestController) {
        checkOutButton.addActionListener(guestController);
    }

    public JButton getViewCheckOutButton() {
        return viewCheckOutButton;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JButton getCheckoutButton() {
        return checkOutButton;
    }
    public JTable getTable(){ return table; }
    public void setTableModel(DefaultTableModel model) { this.tableModel = model; }

    public DefaultTableModel getTableModel() {
        return tableModel;
    }
    public void addRefreshButtonListener(ActionListener listener) {
        refresh.addActionListener(listener);
    }
} // end of GuestScreen class 

