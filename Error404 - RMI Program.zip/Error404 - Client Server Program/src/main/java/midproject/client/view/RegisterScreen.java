package midproject.client.view;

import javax.swing.*;
import java.awt.*;

public class RegisterScreen extends Screen {
    // Fields
    private JLabel registerTitleLabel = new JLabel(new ImageIcon("src/main/java/preproject/utilities/registerTitle.png"));
    private JTextField firstNameField = new JTextField();
    private JTextField lastNameField = new JTextField();
    private JTextField ageField = new JTextField();
    private JTextField phoneNumberField = new JTextField();
    private JTextField emailField = new JTextField();
    private JPasswordField passwordField = new JPasswordField();
    private JPasswordField confirmPasswordField = new JPasswordField();
    private JLabel firstNameLabel = new JLabel("First Name:");
    private JLabel lastNameLabel = new JLabel("Last Name:");
    private JLabel ageLabel = new JLabel("Age:");
    private JLabel phoneNumberLabel = new JLabel("Phone Number:");
    private JLabel emailLabel = new JLabel("Email:");
    private JLabel passwordLabel = new JLabel("Password:");
    private JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
    private JCheckBox showPassword = new JCheckBox("Show password");
    private JButton signUpButton = new JButton("SIGN UP");
    private JButton clearButton = new JButton("CLEAR");
    private static final Font FONT = new Font("Tahoma", Font.BOLD, 18);
    private static final Color COLOUR = new Color(128, 128, 128);

    public RegisterScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }

    private void initializeComponents(){
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel(){
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(102, 153, 204));

        JLabel headerLabel = new JLabel("REGISTER");
        headerLabel.setForeground(new Color(250,250,250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 60));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(DefaultScreen.WIDTH / 2 - 150, 100, 500, 50);

        firstNameLabel.setFont(FONT);
        mainPanel.add(firstNameLabel);
        firstNameLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,250,200,30);

        lastNameLabel.setFont(FONT);
        mainPanel.add(lastNameLabel);
        lastNameLabel.setBounds(DefaultScreen.WIDTH / 2 + 150,250,200,30);

        ageLabel.setFont(FONT);
        mainPanel.add(ageLabel);
        ageLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,325,200,30);

        phoneNumberLabel.setFont(FONT);
        mainPanel.add(phoneNumberLabel);
        phoneNumberLabel.setBounds(DefaultScreen.WIDTH / 2 + 150,325,200,30);

        emailLabel.setFont(FONT);
        mainPanel.add(emailLabel);
        emailLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,400,200,30);

        passwordLabel.setFont(FONT);
        mainPanel.add(passwordLabel);
        passwordLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,475,200,30);

        confirmPasswordLabel.setFont(FONT);
        mainPanel.add(confirmPasswordLabel);
        confirmPasswordLabel.setBounds(DefaultScreen.WIDTH / 2 - 475,550,200,30);

        firstNameField = new JTextField();
        mainPanel.add(firstNameField);
        firstNameField.setBounds(DefaultScreen.WIDTH / 2 - 275,250,200,30);

        lastNameField = new JTextField();
        mainPanel.add(lastNameField);
        lastNameField.setBounds(DefaultScreen.WIDTH / 2 + 350,250,200,30);

        ageField = new JTextField();
        mainPanel.add(ageField);
        ageField.setBounds(DefaultScreen.WIDTH / 2 - 275,325,200,30);

        phoneNumberField = new JTextField();
        mainPanel.add(phoneNumberField);
        phoneNumberField.setBounds(DefaultScreen.WIDTH / 2 + 350,325,200,30);

        emailField = new JTextField();
        mainPanel.add(emailField);
        emailField.setBounds(DefaultScreen.WIDTH / 2 - 275,400,350,30);

        passwordField = new JPasswordField();
        mainPanel.add(passwordField);
        passwordField.setBounds(DefaultScreen.WIDTH / 2 - 275,475,350,30);

        confirmPasswordField = new JPasswordField();
        mainPanel.add(confirmPasswordField);
        confirmPasswordField.setBounds(DefaultScreen.WIDTH / 2 - 275,550,350,30);

        // Show password checkbox
        mainPanel.add(showPassword);
        showPassword.setBounds(525, 585, 129, 23);
        showPassword.setBackground(new Color(211, 211, 211));

        mainPanel.add(signUpButton);
        signUpButton.setBounds(DefaultScreen.WIDTH / 2 - 175, 625, 100, 40);
        signUpButton.setBackground(new Color(143, 188, 143));

        mainPanel.add(clearButton);
        clearButton.setBounds(DefaultScreen.WIDTH / 2 + 75, 625, 100, 40);
        clearButton.setBackground(new Color(128, 128, 128));

        return mainPanel;
    }

    public JTextField getFirstNameField() { return firstNameField; }
    public JTextField getLastNameField() { return lastNameField; }
    public JTextField getAgeField() { return ageField; }
    public JTextField getPhoneNumberField() { return phoneNumberField; }
    public JTextField getEmailField() { return emailField; }
    public JPasswordField getPasswordField() { return passwordField; }
    public JPasswordField getConfirmPasswordField() { return confirmPasswordField; }
    public JCheckBox getShowPassword() { return showPassword; }
    public JButton getSignUpButton() { return signUpButton; }
    public JButton getClearButton() { return clearButton; }
} // end of RegisterScreen class 
