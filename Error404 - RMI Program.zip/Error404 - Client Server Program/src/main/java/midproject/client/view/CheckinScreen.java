package midproject.client.view;

import javax.swing.*;
import java.awt.*;

public class CheckinScreen extends Screen {
    private JTextField bookingIDField = new JTextField();
    private JButton clearButton, checkInButton;

    public CheckinScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }
    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }
    public JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel titleLabel = new JLabel("CHECK-IN");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(675, 70, 500, 50);
        mainPanel.add(titleLabel);

        JLabel bookingIDLabel = new JLabel("Booking ID: ");
        bookingIDLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        bookingIDLabel.setBounds(620, 205, 200, 65);
        bookingIDField.setBounds(750, 215, 200, 40);
        mainPanel.add(bookingIDLabel);
        mainPanel.add(bookingIDField);

        clearButton = new JButton("Clear");
        clearButton.setBounds(680, 680, 90, 40);
        clearButton.setBackground(new Color(192, 192, 192));
        clearButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        mainPanel.add(clearButton);

        checkInButton = new JButton("Check-in");
        checkInButton.setBounds(830, 680, 130, 40);
        checkInButton.setBackground(new Color(143, 188, 143));
        checkInButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        mainPanel.add(checkInButton);

        return mainPanel;
    }

    public JButton getClearButton() {
        return clearButton;
    }

    public JButton getCheckInButton() {
        return checkInButton;
    }

    public JTextField getBookingIDField() {
        return bookingIDField;
    }

} // end of CheckinScreen class 


