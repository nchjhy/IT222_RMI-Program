package midproject.client.view;

import com.toedter.calendar.JDateChooser;

import javax.swing.*;
import java.awt.*;

public class DisableScreen extends Screen{


    private JButton clearButton, disableButton;

    private JDateChooser fromDateChooser = new JDateChooser();

    private JDateChooser toDateChooser = new JDateChooser();

    private JComboBox<String> reasonComboBox;

    public DisableScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }
    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }
    public JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));
    
        JLabel titleLabel = new JLabel("DISABLE DATES");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(630, 70, 500, 50);
        mainPanel.add(titleLabel);
    
        JLabel fromDateLabel = new JLabel("From");
        fromDateLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        fromDateLabel.setBounds(630, 205, 200, 65);
        fromDateChooser = new JDateChooser();
        fromDateChooser.setBounds(750, 215, 200, 40);
        mainPanel.add(fromDateLabel);
        mainPanel.add(fromDateChooser);
    
        JLabel toDateLabel = new JLabel("To");
        toDateLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        toDateLabel.setBounds(630, 273, 200, 65);
        toDateChooser = new JDateChooser();
        toDateChooser.setBounds(750, 285, 200, 40);
        mainPanel.add(toDateLabel);
        mainPanel.add(toDateChooser);
    
        JLabel reasonTypeLabel = new JLabel("Reason: ");
        reasonTypeLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        reasonTypeLabel.setBounds(630, 340, 200, 65);
        reasonComboBox = new JComboBox<>(getReasonTypeOptions());
        mainPanel.add(reasonComboBox);
        mainPanel.add(reasonTypeLabel);
        reasonComboBox.setBounds(750,350,200,40);
    
        clearButton = new JButton("Clear");
        clearButton.setBounds(680, 680, 110, 40);
        clearButton.setBackground(new Color(192, 192, 192));
        clearButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        mainPanel.add(clearButton);
    
        disableButton = new JButton("Disable");
        disableButton.setBounds(830, 680, 110, 40);
        disableButton.setBackground(new Color(143, 188, 143));
        disableButton.setFont(new Font("Tahoma", Font.BOLD, 12));
        mainPanel.add(disableButton);
    
         
        reasonComboBox.setSelectedItem("Select");

        return mainPanel;
    }

    public JDateChooser getFromDateChooser () {
        return fromDateChooser;
    }

    public JDateChooser getToDateChooser () {
        return toDateChooser;
    }

    private String[] getReasonTypeOptions() {
        return new String[]{"Under Maintenance", "Not Available", "Reserved by others", "Others"};
    }

    public JComboBox<String> getReasonTypeComboBox() {
        return reasonComboBox; }

    public JButton getClearButton() {
        return clearButton;
    }

    public JButton getDisableButton() {
        return disableButton;
    }

} // end of DisableScreen class

