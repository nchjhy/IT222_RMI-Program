package midproject.client.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class UserScreen extends Screen {
    private JTextField searchField;
    private JButton searchButton, banButton, unbanButton, deleteButton;
    private JTable table;
    private DefaultTableModel tableModel;
    private final JButton refresh = new JButton(new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/refresh.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT)));

    public UserScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        refresh.setBounds(1510, 21, 20, 20);
        add(refresh);

        JLabel headerLabel = new JLabel("ACCOUNTS REGISTERED");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(650, 10, 300, 30);

        JLabel searchLabel = new JLabel("Search: ");
        mainPanel.add(searchLabel);
        searchLabel.setBounds(10, 20, 60, 20);

        searchField = new JTextField(15);
        mainPanel.add(searchField);
        searchField.setBounds(80, 15, 120, 30);

        searchButton = new JButton("Search");
        mainPanel.add(searchButton);
        searchButton.setBounds(210, 15, 80, 30);

        banButton = new JButton("Ban");
        mainPanel.add(banButton);
        banButton.setBounds(625, 800, 100, 40);
        banButton.setBackground(new Color(184,134,11));
        banButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        unbanButton = new JButton("Unban");
        mainPanel.add(unbanButton);
        unbanButton.setBounds(740, 800, 100, 40);
        unbanButton.setBackground(new Color(143, 188, 143));
        unbanButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        deleteButton = new JButton("Delete");
        mainPanel.add(deleteButton);
        deleteButton.setBounds(855, 800, 100, 40);
        deleteButton.setBackground(new Color(205, 92, 92));
        deleteButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        // Create the table
        String[] columnNames = {"Account Number", "First Name", "Last Name", "Phone Number", "Email Address", "Admin Status", "Banned Status", "Online Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane);
        scrollPane.setBounds(10, 50, DefaultScreen.WIDTH - 20, DefaultScreen.HEIGHT - 180);

        return mainPanel;
    }

    public JTextField getSearchField() { return searchField; }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JButton getBanButton() {
        return banButton;
    }

    public JButton getUnbanButton() {
        return unbanButton;
    }

    public JButton getDeleteButton() {
        return deleteButton;
    }

    public JTable getTable() { return table; }

    public DefaultTableModel getTableModel() { return tableModel; }

    public void setTableModel(DefaultTableModel tableModel) { this.tableModel = tableModel; }
    public void addRefreshButtonListener(ActionListener listener) {
        refresh.addActionListener(listener);
    }
} // end of UserScreen class 
