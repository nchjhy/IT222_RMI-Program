package midproject.client.view;

import javax.swing.*;
import java.awt.*;

public class ClientHomeScreen extends Screen {
    private JPanel dashboardPanel = new JPanel();
    private JLabel welcomeLabel = new JLabel("Welcome to Error 404 Transients");
    private JLabel backgroundLabel = new JLabel(new ImageIcon("src/main/java/midproject/utilities/bg.png"));
    private JButton profileButton = new JButton("Your Profile", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/user.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton annoucementButton = new JButton("Announce", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/announce.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton bookingButton = new JButton("Booking", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/booking.png").getImage().getScaledInstance(45, 45,Image.SCALE_DEFAULT)));
    private JButton logoutButton = new JButton("Logout", new ImageIcon((new ImageIcon("src/main/java/midproject/utilities//logout.png").getImage().getScaledInstance(30, 30, Image.SCALE_DEFAULT))));
    private JButton viewBookingButton = new JButton("<html>View previous<br/>Bookings</html>", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/bhistory.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private JButton bookNowButton = new JButton("Book Now", new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/booking.png").getImage().getScaledInstance(45, 45, Image.SCALE_DEFAULT)));
    private static final Font FONT = new Font("Tahoma", Font.BOLD, 25);

    public ClientHomeScreen() {
        getBackToHomeButton().setVisible(true);
        setBackground(new Color(113, 146, 172));

        dashboardPanel.setBounds(125, 295, 1367, 510);
        dashboardPanel.setBackground(new Color(234,235,254));
        dashboardPanel.setLayout(null);
        add(dashboardPanel);

        welcomeLabel.setBounds(150, 100, 1300, 80);
        welcomeLabel.setFont(new Font("Georgia", Font.BOLD, 50));
        welcomeLabel.setForeground(Color.WHITE);
        add(welcomeLabel);


        backgroundLabel.setBounds(0, 10, 1620, 300);
        add(backgroundLabel);

        annoucementButton.setBackground(new Color(30, 75, 135));
        annoucementButton.setForeground(Color.WHITE);
        annoucementButton.setFont(FONT);
        annoucementButton.setBorder(null);
        annoucementButton.setBounds(150, 50, 255, 125);
        add(annoucementButton);
        dashboardPanel.add(annoucementButton);

        bookingButton.setBackground(new Color(30, 75, 135));
        bookingButton.setForeground(Color.WHITE);
        bookingButton.setFont(FONT);
        bookingButton.setBorder(null);
        bookingButton.setBounds(555, 50, 255, 125);
        add(bookingButton);
        dashboardPanel.add(bookingButton);

        viewBookingButton.setBackground(new Color(30, 75, 135));
        viewBookingButton.setForeground(Color.WHITE);
        viewBookingButton.setFont(FONT);
        viewBookingButton.setBorder(null);
        viewBookingButton.setBounds(950, 50, 255, 125);
        add(viewBookingButton);
        dashboardPanel.add(viewBookingButton);

        bookNowButton.setBackground(new Color(30, 75, 135));
        bookNowButton.setForeground(Color.WHITE);
        bookNowButton.setFont(FONT);
        bookNowButton.setBorder(null);
        bookNowButton.setBounds(150, 350, 255, 125);
        add(bookNowButton);
        dashboardPanel.add(bookingButton);

        profileButton.setBackground(new Color(30, 75, 135));
        profileButton.setForeground(Color.WHITE);
        profileButton.setFont(FONT);
        profileButton.setBorder(null);
        profileButton.setBounds(555, 250, 255, 125);
        add(profileButton);
        dashboardPanel.add(profileButton);

        logoutButton.setBackground(new Color(30, 75, 135));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFont(new Font("Tahoma", Font.BOLD, 15));
        logoutButton.setBackground(new Color(205, 92, 92));
        logoutButton.setBorder(null);
        logoutButton.setBounds(625, 450, 120, 40);
        add(logoutButton);
        dashboardPanel.add(logoutButton);

    }

    public void updateWelcomeLabelAlpha(float alpha) {
        welcomeLabel.setForeground(new Color(255, 255, 255, (int) (255 * alpha)));
    }

    public JLabel getWelcomeLabel() { return welcomeLabel; }
    public JButton getBookNow() { return bookNowButton;}
    public JButton getBookingButton() { return bookingButton; }
    public JButton getProfileButton() { return profileButton; }
    public JButton getLogoutButton(){ return logoutButton; }
    public JButton getViewBookingButton() { return viewBookingButton; }
    public JButton getAnnouncementButton() { return annoucementButton; }
    public JButton getBookNowButton() { return bookNowButton; }

} // end of ClientHomeScreen class 
