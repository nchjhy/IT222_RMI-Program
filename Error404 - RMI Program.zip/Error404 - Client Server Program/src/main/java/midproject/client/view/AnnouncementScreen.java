package midproject.client.view;

import midproject.shared.Announcement;
import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.List;

public class AnnouncementScreen extends Screen {
    // Fields
    private JLabel titleLabel = new JLabel();
    private DefaultListModel<String> announcementListModel = new DefaultListModel<>();
    private JList<String> announcementList = new JList<>(announcementListModel);
    private JScrollPane announcementScroll = new JScrollPane(announcementList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
    private JTextArea announcementArea = new JTextArea();
    private JButton announceButton = new JButton("Announce");

    public AnnouncementScreen() {
        initializeComponents();
        setLayout(new BorderLayout());
        getBackButton().setVisible(true);

        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        JLabel titleLabel = new JLabel("Announcements!");
        titleLabel.setFont(new Font("Tahoma", Font.BOLD, 50));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(100, 50, 700, 50);
        mainPanel.add(titleLabel);

        announcementList.setFont(new Font("Tahoma", Font.PLAIN, 18));
        announcementScroll.setBounds(100, 130, 1400, 500);
        mainPanel.add(announcementScroll);

        announcementArea.setBounds(100, 650, 1300, 50);
        announcementArea.setBackground(new Color(220, 220, 220));
        announcementArea.setFont(new Font("Tahoma", Font.PLAIN, 18));
        mainPanel.add(announcementArea);

        announceButton.setBackground(new Color(30, 75, 135));
        announceButton.setForeground(Color.WHITE);
        announceButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
        announceButton.setBorder(null);
        announceButton.setBounds(1400, 650, 100, 50);
        mainPanel.add(announceButton);

        add(mainPanel);
    }

    public void setAnnouncementListData(List<Announcement> announcements) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        for (Announcement announcement : announcements) {
            announcementListModel.addElement(sdf.format(announcement.getDate()) + " " + announcement.getAccount() + ": " + announcement.getMessage());
        }
    }

    public DefaultListModel<String> getAnnouncementListModel() {
        return announcementListModel;
    }

    private void initializeComponents() {
        announcementArea = new JTextArea();
        announceButton = new JButton("Announce");
    }

    public JTextArea getAnnoucementArea() {
        return announcementArea;
    }

    public JButton getAnnouceButton() {
        return announceButton;
    }
} // end of AnnouncementScreen class 
