package midproject.client.view;

import midproject.shared.Booking;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;

public class BookingHistoryScreen extends Screen {
    private JTextField searchField;
    private JButton searchButton;
    private JTable table;
    private DefaultTableModel tableModel;
    private JButton refresh = new JButton(new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/refresh.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT)));

    public BookingHistoryScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
    }

    private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        refresh.setBounds(1510, 22, 20, 20);
        add(refresh);

        JLabel headerLabel = new JLabel("BOOKING HISTORY");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(DefaultScreen.WIDTH / 2 - 100, 10, 250, 30);

        JLabel searchLabel = new JLabel("Search: ");
        mainPanel.add(searchLabel);
        searchLabel.setBounds(10, 20, 60, 20);

        searchField = new JTextField(15);
        mainPanel.add(searchField);
        searchField.setBounds(80, 15, 120, 30);

        searchButton = new JButton("Search");
        mainPanel.add(searchButton);
        searchButton.setBounds(210, 15, 80, 30);

        // Create the table
        String[] columnNames = {"Booking ID", "First Name", "Last Name", "Phone Number", "Email Address", "Check-in Date", "Check-out Date", "Room Type", "Room Capacity", "Days Booked", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane);
        scrollPane.setBounds(10, 50, DefaultScreen.WIDTH - 20, DefaultScreen.HEIGHT - 180);

        return mainPanel;
    }

    public void addSearchButtonListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }

    public void addRefreshButtonListener(ActionListener listener) {
        refresh.addActionListener(listener);
    }

    public String getSearchKeyword() {
        return searchField.getText();
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public DefaultTableModel getTableModel() {
        return tableModel;
    }

    public void setTableModel(DefaultTableModel tableModel) { this.tableModel = tableModel; }

    public void setAppointmentListData(List<Booking> appointments) {
        for (Booking booking : appointments) {
            Object[] rowData = {booking.getFirstName(), booking.getLastName(), booking.getPhoneNumber(),
                    booking.getCheck_in_date(), booking.getCheck_out_date(), booking.getDaysStayed()};
            tableModel.addRow(rowData);
        }
    }
    
} // end of BookingHistoryScreen class 

