package midproject.client.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;


public class ViewAppointmentsScreen extends Screen {
    // Fields
    private final JLabel titleLabel = new JLabel();
    private JTextField searchField;
    private JButton searchButton, editButton, approveButton, declineButton;;
    private JTable table;
    private DefaultTableModel tableModel;
    private final JButton refresh = new JButton(new ImageIcon(new ImageIcon("src/main/java/midproject/utilities/refresh.png").getImage().getScaledInstance(20, 20, Image.SCALE_DEFAULT)));

    public ViewAppointmentsScreen() {
        initializeComponents();
        getBackButton().setVisible(true);
        setBackground(new Color(113, 146, 172));

        refresh.setBounds(1510, 21, 20, 20);
        add(refresh);
    }

      private void initializeComponents() {
        setLayout(null);

        JPanel mainPanel = createMainPanel();
        add(mainPanel);
        mainPanel.setBounds(0, 0, DefaultScreen.WIDTH, DefaultScreen.HEIGHT);
    }

    private JPanel createMainPanel() {
        JPanel mainPanel = new JPanel(null);
        mainPanel.setBackground(new Color(113, 146, 172));

        refresh.setBounds(1510, 22, 20, 20);
        add(refresh);

        JLabel headerLabel = new JLabel("VIEW BOOKINGS");
        headerLabel.setForeground(new Color(255, 250, 250));
        headerLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
        mainPanel.add(headerLabel);
        headerLabel.setBounds(685, 10, 350, 30);

        JLabel searchLabel = new JLabel("Search: ");
        mainPanel.add(searchLabel);
        searchLabel.setBounds(10, 20, 60, 20);

        searchField = new JTextField(15);
        mainPanel.add(searchField);
        searchField.setBounds(80, 15, 120, 30);

        searchButton = new JButton("Search");
        mainPanel.add(searchButton);
        searchButton.setBounds(210, 15, 80, 30);

        editButton = new JButton("Edit");
        mainPanel.add(editButton);
        editButton.setBounds(625, 800, 100, 40);
        editButton.setBackground(new Color(184,134,11));
        editButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        approveButton = new JButton("Approve");
        mainPanel.add( approveButton);
        approveButton.setBounds(740, 800, 100, 40);
        approveButton.setBackground(new Color(143, 188, 143));
        approveButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        declineButton = new JButton("Decline");
        mainPanel.add(declineButton);
        declineButton.setBounds(855, 800, 100, 40);
        declineButton.setBackground(new Color(205, 92, 92));
        declineButton.setFont(new Font("Tahoma", Font.BOLD, 15));

        // Create the table
        String[] columnNames = {"Booking ID", "First Name", "Last Name", "Phone Number", "Email Address", "Check-in Date", "Check-out Date", "Room Type", "Room Capacity", "Days Booked", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);

        JScrollPane scrollPane = new JScrollPane(table);
        mainPanel.add(scrollPane);
        scrollPane.setBounds(10, 50, DefaultScreen.WIDTH - 20, DefaultScreen.HEIGHT - 180);

        return mainPanel;
    }

    public void addSearchButtonListener(ActionListener listener) {
        searchButton.addActionListener(listener);
    }

    public void addRefreshButtonListener(ActionListener listener) {
        refresh.addActionListener(listener);
    }

    public String getSearchKeyword() {
        return searchField.getText();
    }

    public JButton getSearchButton() {
        return searchButton;
    }

    public JTextField getSearchField() {
        return searchField;
    }

    public JButton getEditButton() {
        return editButton;
    }

    public JButton getApproveButton() {
        return approveButton;
    }

    public JButton getDeclineButton() {
        return declineButton;
    }

    public DefaultTableModel getTableModel() {
        return tableModel;
    }
    public JTable getTable() { return table; }

    public void setTableModel(DefaultTableModel tableModel) { 
        this.tableModel = tableModel; 
    }

} // end of ViewAppointmentsScreen class 
