package midproject.client;

import midproject.client.controller.ApplicationController;
import midproject.shared.MidProjectInterface;
import midproject.utilities.IPAdd;
import javax.swing.*;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client {
    private static final int RMI_PORT = 1099;

    public static void main(String[] args) {
        String SERVER_ADDRESS = JOptionPane.showInputDialog(null, "Enter the IP Address of the server:", "Server IP", JOptionPane.QUESTION_MESSAGE);
        IPAdd.setServerIP(SERVER_ADDRESS);
        try {
            Registry registry = LocateRegistry.getRegistry(SERVER_ADDRESS, RMI_PORT);
            MidProjectInterface midProjectInterface = (MidProjectInterface) registry.lookup("MidProjectRMI");

            SwingUtilities.invokeLater(() -> {
                try {
                    ApplicationController applicationController = new ApplicationController(midProjectInterface);
                    applicationController.start();
                } catch (NotBoundException e) {
                    throw new RuntimeException(e);
                } catch (RemoteException e) {
                    System.out.println(e.getMessage());
                }
            });

        } catch (Exception e) {
            System.err.println("Client exception: " + e.getMessage());
            e.printStackTrace();
        }
    }
} // end of Client class

