package midproject.client.model;

import midproject.shared.Account;
import midproject.shared.Announcement;
import midproject.shared.Booking;
import midproject.shared.Room;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class ApplicationModel {
    private Account account;
    private List<Account> accountList;
    private List<Booking> bookingList;
    private List<Booking> guestList;
    private List<Booking> checkOutList;
    private List<Announcement> announcements = new ArrayList<>();
    private List<Room> roomsList;
    private Date loginTime;

    public ApplicationModel() {}
    public void setAccount(Account account) {
        this.account = account;
    }
    public void setAccountList(List<Account> accountList) {
        this.accountList = accountList;
    }
    public void setBookingList(List<Booking> bookingList) {
        this.bookingList = bookingList;
    }
    public void setGuestList(List<Booking> guestList) { this.guestList = guestList; }
    public void setCheckOutList(List<Booking> checkOutList) { this.checkOutList = checkOutList;}
    public Account getAccount() {
        return account;
    }
    public List<Account> getAccountList() {
        return accountList;
    }
    public List<Booking> getBookingList() {
        return bookingList;
    }
    public List<Booking> getGuestList() { return guestList; }
    public List<Booking> getCheckOutList() { return checkOutList; }
    public List<Announcement> getAnnouncements() { return announcements; }
    public void setAnnouncements(List<Announcement> announcements) { this.announcements = announcements; }
    public Date getLoginTime()  { return loginTime; }
    public void setLoginTime(Date loginTime) { this.loginTime = loginTime; }
    public List<Room> getRoomsList() { return roomsList; }
    public void setRoomsList(List<Room> roomsList) { this.roomsList = roomsList; }

} // end of ApplicationModel.java
