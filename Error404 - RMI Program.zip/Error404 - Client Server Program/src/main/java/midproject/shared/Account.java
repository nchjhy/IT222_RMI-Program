package midproject.shared;

import java.io.Serializable;

public class Account implements Serializable {
    // Fields
    private String accountNumber;
    private String firstName;
    private String lastName;
    private String age;
    private String phoneNumber;
    private String email;
    private String password;
    private boolean isAdmin;
    private boolean isBanned;
    private boolean isOnline;
    private String UUID;

    // Constructor
    public Account(String accountNumber, String firstName, String lastName, String age, String phoneNumber, String email, String password, String UUID) {
        this.accountNumber = accountNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = false;
        this.isBanned = false;
        this.isOnline = false;
        this.UUID = UUID;
    }

    public Account(String accountNumber, String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, String UUID) {
        this.accountNumber = accountNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = false;
        this.isOnline = false;
        this.UUID = UUID;
    }

    public Account(String accountNumber, String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, boolean isBanned, String UUID) {
        this.accountNumber = accountNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = isBanned;
        this.isOnline = false;
        this.UUID = UUID;
    }

    public Account(String accountNumber, String firstName, String lastName, String age, String phoneNumber, String email, String password, boolean isAdmin, boolean isBanned, boolean isOnline, String UUID) {
        this.accountNumber = accountNumber;
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
        this.isBanned = isBanned;
        this.isOnline = isOnline;
        this.UUID = UUID;
    }

    // Getters & Setters

    public String getAccountNumber() { return accountNumber; }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getAge() {
        return age;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public String getEmail() {
        return email;
    }
    public String getPassword() {
        return password;
    }
    public boolean isAdmin() {
        return isAdmin;
    }
    public boolean isBanned() {
        return isBanned;
    }
    public boolean isOnline() {
        return isOnline;
    }
    public String getUUID() { return UUID; }

    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public void setAdmin(boolean isAdmin) {
        this.isAdmin = isAdmin;
    }
    public void setBanned(boolean isBanned) {
        this.isBanned = isBanned;
    }
    public void setOnline(boolean isOnline) {
        this.isOnline = isOnline;
    }
    public void setAge(String age) {
        this.age = age;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    public void setUUID(String uUID) {
        UUID = uUID;
    }
} // end of Account class
