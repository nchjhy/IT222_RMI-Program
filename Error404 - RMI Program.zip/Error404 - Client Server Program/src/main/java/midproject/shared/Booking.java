package midproject.shared;

import java.io.Serializable;

public class Booking implements Serializable {
    // Fields
    private String bookingID;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String emailAddress;
    private String check_in_date;
    private String check_out_date;
    private String roomType;
    private String roomCapacity;
    private String uniqueID;
    private String daysStayed;
    private String status;

    // create new booking
    public Booking(String bookingID, String firstName, String lastName, String phoneNumber, String emailAddress,
                   String check_in_date, String check_out_date, String roomType, String roomCapacity, String uniqueID) {
        this.bookingID = bookingID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.check_in_date = check_in_date;
        this.check_out_date = check_out_date;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.uniqueID = uniqueID;
        this.status = "pending";
    }

    // populate guest and checkout table
    public Booking(String bookingID, String firstName, String lastName, String phoneNumber, String emailAddress,
                   String check_in_date, String check_out_date, String roomType, String roomCapacity, String uniqueID, String daysStayed) {
        this.bookingID = bookingID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.check_in_date = check_in_date;
        this.check_out_date = check_out_date;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.uniqueID = uniqueID;
        this.daysStayed = daysStayed;
        this.status = "pending";
    }

    // populate booking history table
    public Booking(String bookingID, String firstName, String lastName, String phoneNumber, String emailAddress,
                   String check_in_date, String check_out_date, String roomType, String roomCapacity, String uniqueID, String daysStayed, String status) {
        this.bookingID = bookingID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.check_in_date = check_in_date;
        this.check_out_date = check_out_date;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.uniqueID = uniqueID;
        this.daysStayed = daysStayed;
        this.status = status;
    }

    public void editBooking(String firstName, String lastName, String phoneNumber, String emailAddress,
                            String check_in_date, String check_out_date, String roomType, String roomCapacity,
                            String uniqueID) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.emailAddress = emailAddress;
        this.check_in_date = check_in_date;
        this.check_out_date = check_out_date;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.uniqueID = uniqueID;
    }

    public void editBooking(String firstName, String lastName, String phoneNumber, String emailAddress,
                            String check_in_date, String check_out_date, String roomType, String roomCapacity,
                            String uniqueID, String daysStayed) {
        editBooking(firstName, lastName, phoneNumber, emailAddress, check_in_date, check_out_date, roomType,
                roomCapacity, uniqueID);
        this.daysStayed = daysStayed;
    }

    public void editBooking(String firstName, String lastName, String phoneNumber, String emailAddress,
                            String check_in_date, String check_out_date, String roomType, String roomCapacity,
                            String uniqueID, String daysStayed, String status) {
        editBooking(firstName, lastName, phoneNumber, emailAddress, check_in_date, check_out_date, roomType,
                roomCapacity, uniqueID, daysStayed);
        this.status = status;
    }

    // Getters
    public String getBookingID() { return bookingID; }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public String getEmailAddress() {
        return emailAddress;
    }
    public String getCheck_in_date() {
        return check_in_date;
    }
    public String getCheck_out_date() {
        return check_out_date;
    }
    public String getRoomType() { return roomType; }
    public String getRoomCapacity() {
        return roomCapacity;
    }
    public String getUniqueID() {
        return uniqueID;
    }
    public String getDaysStayed() {
        return daysStayed;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setUniqueID(String uniqueID) {this.uniqueID = uniqueID; }

    // Getting only relevant data for the appointment (all null is ignored)
    private String getAppointment() {
        String appointments = "";
        appointments += "*» Booking with Booking ID: " + this.bookingID + " has been submitted by " + this.firstName + " " + this.lastName
                + " which will start on " + this.check_in_date + " and will end on " + this.check_out_date + ".";
        return appointments;
    }

    // toString method
    @Override
    public String toString() {
        String appointments = getAppointment();
        return appointments;
    }
} // end of Booking class 
