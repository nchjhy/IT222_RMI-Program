package midproject.shared;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;

public interface MidProjectInterface extends Remote {

    public Object[] fetchData() throws RemoteException;
    public Object[] fetchAnnouncements(Date loginTime) throws RemoteException;
    public Object[] login(String email, String password) throws RemoteException;
    public Object[] logout(Account account) throws RemoteException;
    public Object[] announce(String account, String s) throws RemoteException;
    public Object[] register(String firstName, String lastName, String age, String phoneNum, String email, String password, String confirmPass, String uniqueID) throws RemoteException;
    public Object[] booking (String firstName, String lastName, String phoneNum, String email, String checkInDate, String checkOutDate, String roomType, String roomCapacity, String uniqueID) throws RemoteException;
    public Object[] checkin(String bookingID) throws RemoteException;
    public Object[] cancelBooking(String bookingID) throws RemoteException;
    public Object [] checkout(String bookingID, String firstName, String lastName, String phoneNum, String email, String checkInDate, String checkOutDate, String roomType, String roomCapacity, String uniqueID) throws RemoteException;
    public Object[] ban(int selectedRow) throws RemoteException;
    public Object[] unban(int selectedRow) throws RemoteException;
    public Object[] delete(int selectedRow) throws RemoteException;
    public Object[] approve(int selectedRow) throws RemoteException;
    public Object[] decline(int selectedRow) throws RemoteException;
    public Object[] editByClient(int selectedRow) throws RemoteException;
    public Object[] editByAdmin(int selectedRow) throws RemoteException;
    public Object[] addRoom (String roomType, String roomCapacity, String imgSrc) throws RemoteException;
    public Object[] disableDates (String start, String end, String reason) throws RemoteException;
   void registerCallback(DataRefreshCallback callback) throws RemoteException;
   
} // end if MidProjectInterface class 


 