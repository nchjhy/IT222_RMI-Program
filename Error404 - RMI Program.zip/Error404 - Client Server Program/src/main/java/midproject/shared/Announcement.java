package midproject.shared;
import java.io.Serializable;
import java.util.Date;

public class Announcement implements Serializable {
    private String account;
    private String message;
    private Date date;
    public Announcement(String account, String message, Date date){
        this.account = account;
        this.message = message;
        this.date = date;
    }

    public String getAccount() {
        return account;
    }

    public String getMessage() {
        return message;
    }

    public Date getDate() {
        return date;
    }
} // end of Announcement class
