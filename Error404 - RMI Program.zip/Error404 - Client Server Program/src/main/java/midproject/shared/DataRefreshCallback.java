package midproject.shared;

import midproject.client.controller.ApplicationController;

import java.io.Serializable;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface DataRefreshCallback extends Remote, Serializable {
    public void requestFromUser(Object[] request) throws RemoteException;
    public Object[] getRequest() throws RemoteException;
    public ApplicationController getController() throws RemoteException;
    public void loginCall(Object[] response) throws RemoteException;
    public void broadcastCall(Object[] response) throws RemoteException;
    public void logoutCall(Object[] response) throws RemoteException;
}