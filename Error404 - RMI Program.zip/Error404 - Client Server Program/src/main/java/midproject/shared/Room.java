package midproject.shared;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Room implements Serializable {
    private int roomID;
    private String roomType;
    private String roomCapacity;
    private boolean active;
    private String imgSrc;
    private List<Object[]> bookedDates;
    private List<Object[]> disabledDates;

    public Room(int roomID, String roomType, String roomCapacity, String imgSrc, List<Object[]> disabledDates){
        this.roomID = roomID;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.active = true;
        this.imgSrc = imgSrc;
        this.bookedDates = new ArrayList<>();
        this.disabledDates = disabledDates;
    }
    public Room(int roomID, String roomType, String roomCapacity, boolean active, String imgSrc, List<Object[]> bookedDates, List<Object[]> disabledDates){
        this.roomID = roomID;
        this.roomType = roomType;
        this.roomCapacity = roomCapacity;
        this.active = active;
        this.imgSrc = imgSrc;
        this.bookedDates = bookedDates;
        this.disabledDates = disabledDates;
    }
    public void setActive (boolean active) {
        this.active = true;
    }
    public void setRoomCapacity(String roomCapacity) {
        this.roomCapacity = roomCapacity;
    }

    public void setRoomID(int roomID) {
        this.roomID = roomID;
    }

    public void setRoomType(String roomType) { 
        this.roomType = roomType; 
    }

    public String getRoomType() {
         return roomType; }

    public boolean getActive() {
        return active;
    }

    public String getRoomCapacity() {
        return roomCapacity;
    }

    public int getRoomID() {
        return roomID;
    }

    public List<Object[]> getBookedDates() {
        return bookedDates;
    }
    public void addBookedDate(Object[] bookedDate) { this.bookedDates.add(bookedDate); }
    public void removeBookedDate(Object[] bookedDate) {
        for (Object[] dates : bookedDates){
            if (dates[0] == bookedDate[0] && dates[1] == bookedDate[1]){
                bookedDates.remove(dates);
            }
        }
    }
    public List<Object[]> getDisabledDates() { return disabledDates; }
    public void addDisabledDates(Object[] disabledDates) { this.disabledDates.add(disabledDates); }
    public void removeDisabledDate(Object[] disabledDate) {
        for (Object[] dates : disabledDates){
            if (dates[0] == disabledDate[0] && dates[1] == disabledDate[1]){
                disabledDates.remove(dates);
            }
        }
    }

    public void setImgSrc(String imgSrc) {
        this.imgSrc = imgSrc;
    }

    public String getImgSrc() {
        return imgSrc;
    }

    public String datesToString(){
        String result = roomType + ": ";
        for (Object[] dates : getBookedDates()){
            result += "{"+dates[0] +", "+dates[1]+"}, ";
        }
        return result;
    }
} // end of Room class
