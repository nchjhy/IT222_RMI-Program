package midproject.shared;

import midproject.client.controller.ApplicationController;

import java.io.Serializable;
import java.rmi.RemoteException;

public class DataRefreshCallbackImpl implements DataRefreshCallback, Serializable {

    private ApplicationController applicationController;
    private Object[] request;
    public DataRefreshCallbackImpl(ApplicationController applicationController) throws RemoteException{
        this.applicationController = applicationController;
    }
    @Override
    public void requestFromUser(Object[] request) throws RemoteException {
        this.request = request;
    }

    @Override
    public Object[] getRequest() throws RemoteException {
        return request;
    }

    @Override
    public ApplicationController getController() throws RemoteException {
        return applicationController;
    }

    @Override
    public void loginCall(Object[] response) throws RemoteException {
        applicationController.handleIncomingData(response);
    }

    @Override
    public void broadcastCall(Object[] response) throws RemoteException {
        applicationController.handleIncomingData(response);
    }

    @Override
    public void logoutCall(Object[] response) throws RemoteException {
        applicationController.handleIncomingData(response);
    }
}