package midproject.server.model;

import midproject.server.controller.ClientObserver;
import midproject.shared.Account;
import midproject.shared.Announcement;
import midproject.shared.Booking;
import midproject.shared.Room;
import midproject.utilities.JSONUtility;

import java.util.ArrayList;
import java.util.List;

public class ServerModel {
    private List<Account> accountList;
    private List<Booking> bookingList;
    private List<Booking> guestList;
    private List<Booking> checkOutList;
    private List<Room> roomsList;
    private List<Announcement> announcements = new ArrayList<>();
    private String currentBookingID;
    private String currentAccountNumber;
    private ClientObserver clientObserver;

    public void setClientObserver(ClientObserver clientObserver) {
        this.clientObserver = clientObserver;
    }

    /**
     * notifies the server of any changes made from any client
     */
    public void notifyObserver() {
        System.out.println("Notifying clients");
        clientObserver.onDataChanged();
    }

    public ServerModel() {
        // obtain all the data from the xml files
        try {
            accountList = JSONUtility.readAccountJSON();
            bookingList = JSONUtility.readBookingJSON();
            guestList = JSONUtility.readGuestJSON();
            checkOutList = JSONUtility.readCheckoutJSON();
            setCurrentAccountNumber(String.valueOf(accountList.size()+1));
            setCurrentBookingID(String.valueOf(bookingList.size()+1));
            roomsList = JSONUtility.readRoomsJSON();
            //roomsList = new ArrayList<>();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

        // updates the data of the three rooms
        populateRooms();
//        for (int i = 0; i < roomsList.size(); i++){
//            if (roomsList.get(i).getRoomType().equals("Pair Room")){
//                roomsList.get(i).setImgSrc("src/main/java/midproject/utilities/Pair_room.jpg");
//            } else if (roomsList.get(i).getRoomType().equals("Family Room")){
//                roomsList.get(i).setImgSrc("src/main/java/midproject/utilities/Fam_room.jpg");
//            } else if (roomsList.get(i).getRoomType().equals("Large Room")){
//                roomsList.get(i).setImgSrc("src/main/java/midproject/utilities/Large_room.jpg");
//            }
//        }
    }

    public void populateRooms(){
        if (roomsList.isEmpty()){
            Room newRoom = new Room(0, "box", null, null, new ArrayList<>());
            roomsList.add(newRoom);
        }

//            for (int i = 0; i <= bookingList.size(); i++){
//                if (i == bookingList.size()){
//                    break;
//                }
//                else if (roomsList.isEmpty()){
//                    Room newRoom = new Room(1, bookingList.get(i).getRoomType(), Integer.parseInt(bookingList.get(i).getRoomCapacity()));
//                    roomsList.add(newRoom);
//                } else{
//                    for (int j = 0; j < roomsList.size(); j++){
//                        if (roomsList.get(j).getRoomType().equals(bookingList.get(i).getRoomType())){
//                            if (bookingList.get(i).getStatus().equals("approved") || bookingList.get(i).getStatus().equals("checked-in")){
//                                roomsList.get(j).addBookedDate(new Object[]{bookingList.get(i).getCheck_in_date(), bookingList.get(i).getCheck_out_date()});
//                            }
//                            break;
//                        }
//                        if (!roomsList.get(j).getRoomType().equals(bookingList.get(i).getRoomType()) && j == roomsList.size() - 1){
//                            Room anotherRoom = new Room(roomsList.size() + 1, bookingList.get(i).getRoomType(), Integer.parseInt(bookingList.get(i).getRoomCapacity()));
//                            roomsList.add(anotherRoom);
//                        }
//                    }
//                }
//            }

    }
    public List<Account> getAccountList() { return accountList; }
    public List<Booking> getGuestList() { return guestList; }
    public List<Booking> getBookingList() { return bookingList; }
    public List<Booking> getCheckOutList() { return checkOutList; }
    public String getCurrentBookingID() { return currentBookingID; }
    public String getCurrentAccountNumber() { return currentAccountNumber; }
    public void setCurrentBookingID(String currentBookingID) { this.currentBookingID = currentBookingID; }
    public void setCurrentAccountNumber(String currentAccountNumber) { this.currentAccountNumber = currentAccountNumber; }
    public List<Announcement> getAnnouncements() { return announcements; }
    public List<Room> getRoomsList() { return roomsList; }
} // end of ServerModel
