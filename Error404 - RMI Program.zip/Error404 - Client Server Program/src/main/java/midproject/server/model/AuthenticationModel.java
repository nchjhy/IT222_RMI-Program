package midproject.server.model;

import midproject.shared.Account;
import midproject.shared.Booking;
import midproject.shared.Room;
import midproject.utilities.JSONUtility;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class AuthenticationModel {
    private final ServerModel serverModel;

    public AuthenticationModel(ServerModel serverModel) {
        this.serverModel = serverModel;
    }

    /**
     * validates the credentials upon login
     * @param email the email of the user
     * @param password the password of the user
     * @return an object where index 0 is either null or the account of the user and index 1 being the response message
     */
    public Object[] authenticate(String email, String password) {
        for (Account account : serverModel.getAccountList()) {
            if (account.getEmail().equalsIgnoreCase(email)) {
                if (account.getPassword().equals(password)) {
                    if (account.isBanned()) {
                        return new Object[] {null, "Invalid login\nAccount is banned"};
                    }
                    if (account.isOnline()) {
                        System.out.println("Someone is trying to log in as " + account.getFirstName() + " " + account.getLastName() + " who is already logged in on the system.");
                        return new Object[] {null, "Invalid login\nAccount is already online"};
                    }
                    account.setOnline(true);
                    System.out.println(account.getFirstName() + " " + account.getLastName() + " has logged in.");
                    return new Object[] {account, "Login successful"};
                } else {
                    return new Object[] {null, "Invalid login\nPlease check your email and password"};
                }
            }
        }
        return new Object[] {null, "Invalid login\nAccount not found"};
    } // end of authenticate

    public Object[] registerUser(String accNum, String firstName, String lastName, String age, String phoneNum, String email, String password, String confirmPass, String uniqueID) {

        // Check if fields are empty
        if (firstName.isEmpty() || lastName.isEmpty() || age.isEmpty() || phoneNum.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPass.isEmpty()) {
            return new Object[] {null, "The fields must not be empty."};
        }

        // Check if fields contain multiple consecutive spaces
        if (firstName.matches(".*\\s{2,}.*") || lastName.matches(".*\\s{2,}.*") || email.matches(".*\\s{2,}.*")) {
            return new Object[] {null, "Multiple consecutive spaces are not allowed in first name or last name."};
        }

        // Check if fields contains whitespaces or spaces
        if (firstName.isBlank() || lastName.isBlank() || age.isEmpty() || phoneNum.isBlank() || email.isBlank() || password.isBlank() || confirmPass.isBlank()) {
            return new Object[] {null, "Whitespace or spaces are not allowed."};
        }
    
        // Check if email format is valid
        if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            return new Object[] {null, "The email is not valid."};
        }
    
        // Parse age to an integer and check if it's valid
        try {
            int parsedAge = Integer.parseInt(age);
            if (parsedAge < 18) {
                return new Object[] {null, "Age must not be less than 18. Let an adult register an account for you."};
            } else if (parsedAge > 122) return new Object[] {null, "Age is absurd. "};
        } catch (NumberFormatException e) {
            return new Object[] {null, "Invalid age format. Please provide a valid age."};
        }
    
        // Check if passwords match
        if (!password.equals(confirmPass)) {
            return new Object[] {null, "Check if the passwords match."};
        }

        //Check if phone number is less than 11 digits
        if (phoneNum.length() < 11) {
            return new Object[] {null, "Phone number should have at least 11 digits.\nIt takes the format '09*********'"};
        }
        //Check if phone number contains non-digits
        if (!phoneNum.matches("\\d+")) {
            return new Object[] {null, "Phone number should contain digits only."};
        }
        // Check if email is already registered
        for (Account account : serverModel.getAccountList()) {
            if (account.getEmail().equals(email)) {
                return new Object[] {null, "This email address has been registered."};
            }
        }
    
        // If all checks pass, create a new account
        Account newAccount = new Account(accNum, firstName, lastName, age, phoneNum, email, password, uniqueID);
        serverModel.getAccountList().add(newAccount);
        serverModel.setCurrentAccountNumber(String.valueOf(serverModel.getAccountList().size() + 1));
        try {
            JSONUtility.saveAccountJSON(serverModel.getAccountList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[] {newAccount, "Account created successfully"};
    }

     public Object[] validateBooking(String bookingID, String firstName, String lastName, String phoneNum, String email, String checkInDate, String checkOutDate, String roomType, String roomCapacity, String uniqueID){
        boolean detailsValid = true;
        String response = "";
        if (bookingID == null || firstName == null || lastName == null || phoneNum == null || email == null || checkInDate == null || checkOutDate == null || roomType.equals("Choose Room Type") || roomCapacity == null || uniqueID == null) {
             detailsValid = false;
             response = "Fields must not be empty";
        }

        // Check if fields contain multiple consecutive spaces
        else if (firstName.matches(".*\\s{2,}.*") || lastName.matches(".*\\s{2,}.*") || email.matches(".*\\s{2,}.*")) {
            return new Object[] {null, "Multiple consecutive spaces are not allowed in first name or last name."};
        }

        // Check if fields contain whitespaces or spaces
        else if (firstName.isBlank() || lastName.isBlank() || phoneNum.isBlank() || email.isBlank()) {
            detailsValid = false;
            response = "Whitespace or spaces are not allowed, and all fields must be filled.";
            
        } else if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) { 
            // Check if email format is valid
            detailsValid = false;
            response = "The email is not valid";
        }
    
         else if (phoneNum.length() != 11){
             detailsValid = false;
             response = "The phone number should be 11 digits";
         }

         else if (!phoneNum.matches("\\d+")) {
             detailsValid = false;
             response = "Phone number should contain digits only.";
         }

         // Check if dates are not null
         else if (detailsValid && (checkInDate == null || checkOutDate == null)) {
             detailsValid = false;
             response = "Check-in date or check-out date cannot be null.";
         }

         else if (checkInDate.isBlank()){
             detailsValid = false;
             response = "Please select a check-in date.";
         }

         else if (checkOutDate.isBlank()){
             detailsValid = false;
             response = "Please select a check-out date.";
         }

         // Check if checkout date is after checkin date
         else if (checkInDate.compareTo(checkOutDate) >= 0) {
             detailsValid = false;
             response = "Check-out date must be after check-in date.";
         }
         else if (checkInDate.equals(checkOutDate)){
             detailsValid = false;
             response = "Check-out date must be after check-in date.";
        }

         // Check if room is available from chosen date
         else if (response.isBlank()){
            for (int i = 0; i < serverModel.getRoomsList().size(); i++){
                if (serverModel.getRoomsList().get(i).getRoomType().equals(roomType)){
                    for (Object[] dates : serverModel.getRoomsList().get(i).getBookedDates()){
                        if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                    }
                    break;
                }
            }
        }

        else if (response.isBlank()){
            for (int i = 0; i < serverModel.getRoomsList().size(); i++){
                if (serverModel.getRoomsList().get(i).getRoomType().equals(roomType)){
                    for (Object[] dates : serverModel.getRoomsList().get(i).getBookedDates()){
                        if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
                        }
                    }
                    break;
                }
            }
            for (int i = 0; i < serverModel.getRoomsList().size(); i++){
                if (serverModel.getRoomsList().get(i).getRoomType().equals(roomType)){
                    for (Object[] dates : serverModel.getRoomsList().get(i).getBookedDates()){
                        if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                        if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                            detailsValid = false;
                            response = "Invalid date! The room is booked from " + dates[0] + " until " + dates[1];
                        }
                    }
                    for (int j = 0; j < serverModel.getRoomsList().size(); j++){
                        if (serverModel.getRoomsList().get(j).getRoomType().equals(roomType)){
                            for (Object[] dates : serverModel.getRoomsList().get(j).getDisabledDates()){
                                if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                                if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
                                    detailsValid = false;
                                    response = "Invalid date! The room is unavailable from " + dates[0] + " until " + dates[1];
                                }
                            }
                            break;
                        }
                    }
                    break;
                }
            }
        }



//         if (!roomType.equals("Choose Room Type")){
//             for (int i = 0; i < serverModel.getRoomsList().size(); i++){
//                 if (serverModel.getRoomsList().get(i).getRoomType().equals("Pair Room")){
//                     for (Object[] dates : serverModel.getRoomsList().get(i).getBookedDates()) {
//                         if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                     }
//
//
//                 } else  if (serverModel.getRoomsList().get(i).getRoomType().equals("Family Room")){
//                     for (Object[] dates : serverModel.getRoomsList().get(i).getBookedDates()) {
//                         if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//
//                     }
//
//                 } else  if (serverModel.getRoomsList().get(i).getRoomType().equals("Large Room")){
//                     for (Object[] dates : serverModel.getRoomsList().get(i).getBookedDates()) {
//                         if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) > 0 && checkInDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkInDate.compareTo((String) dates[0]) == 0 && checkInDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) > 0 && checkOutDate.compareTo((String) dates[1]) == 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                         if (checkOutDate.compareTo((String) dates[0]) == 0 && checkOutDate.compareTo((String) dates[1]) < 0) {
//                             detailsValid = false;
//                             response = "Invalid date! The room is checked in from " + dates[0] + " until " + dates[1];
//                         }
//                     }
//                 }
//             }
//         }

         // If there is date overlap or the email is banned, return an error message
         for (Account account : serverModel.getAccountList()) {
             if (account.getEmail().equals(email)) {
                 if (account.isBanned()) {
                     detailsValid = false;
                     response = "This email address is banned.\n You can not book an appointment.";
                 }
             }
         }

         if (detailsValid){
             String daysStayed = calculateDaysStayed(checkInDate, checkOutDate);
             Booking newBooking = new Booking(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID, daysStayed);
             serverModel.getBookingList().add(newBooking);
             try {
                 JSONUtility.saveBookingJSON(serverModel.getBookingList());
             } catch (Exception e) {
                 throw new RuntimeException(e);
             }

             serverModel.setCurrentBookingID(String.valueOf(serverModel.getBookingList().size() + 1));
             response = "Successfully booked";
             return new Object[] {newBooking, response};
         }
         return new Object[] {null, response};
     }

    public Object[] validateCancelBooking(String bookingID){
        int index = 0;

        try {
            for (int j = 0; j < serverModel.getRoomsList().size(); j++){
                for (int i = 0; i < serverModel.getBookingList().size(); i++){
                    if (serverModel.getBookingList().get(i).getBookingID().equals(bookingID)){
                        index = i;
                        if (serverModel.getBookingList().get(index).getStatus().equals("checked-in")){
                            return new Object[] {null, "Booking with bookingID " + serverModel.getBookingList().get(index).getBookingID() + " has already been used and is checked-in. Cannot be cancelled."};
                        } else if (serverModel.getBookingList().get(index).getStatus().equals("checked-out")){
                            return new Object[] {null, "Booking with bookingID " + serverModel.getBookingList().get(index).getBookingID() + " has already been used and is checked-out. Cannot be cancelled."};
                        } else if (serverModel.getBookingList().get(index).getStatus().equals("approved") || serverModel.getBookingList().get(index).getStatus().equals("pending")){
                            if(serverModel.getBookingList().get(index).getRoomType().equals(serverModel.getRoomsList().get(j).getRoomType())){
                                for (Object[] dates : serverModel.getRoomsList().get(j).getBookedDates()){
                                    if (serverModel.getBookingList().get(index).getCheck_out_date().equals(dates[1])){
                                        serverModel.getRoomsList().get(j).getBookedDates().remove(dates);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } catch (NullPointerException e){
            return new Object[]{null, "Booking not found"};
        }

        serverModel.getBookingList().get(index).setStatus("cancelled");
        try {
            JSONUtility.saveBookingJSON(serverModel.getBookingList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[] {index, "Cancelled the booking successfully"};
    }

    public Object[] validateCheckIn(String bookingID){
        int index = 0;
        Booking booking;
        boolean isGood = false;

        try{
            for (int i = 0; i < serverModel.getBookingList().size(); i++){
                if (serverModel.getBookingList().get(i).getBookingID().equalsIgnoreCase(bookingID)){
                    if (serverModel.getBookingList().get(i).getStatus().equals("cancelled")){
                        return new Object[] {null, "Booking has been previously cancelled"};
                    } else if (serverModel.getBookingList().get(i).getStatus().equals("checked-in")){
                        return new Object[] {null, "Booking with bookingID " + serverModel.getBookingList().get(i).getBookingID() + " has already been used and is checked-in."};
                    } else if (serverModel.getBookingList().get(i).getStatus().equals("checked-out")){
                        return new Object[] {null, "Booking with bookingID " + serverModel.getBookingList().get(i).getBookingID() + " has already been used and is checked-out."};
                    } else if (serverModel.getBookingList().get(i).getStatus().equals("pending")){
                        return new Object[] {null, "Booking with bookingID " + serverModel.getBookingList().get(i).getBookingID() + " has a pending status and cannot check-in."};
                    } else if (serverModel.getBookingList().get(i).getStatus().equals("declined")){
                        return new Object[] {null, "Booking with bookingID " + serverModel.getBookingList().get(i).getBookingID() + " has a declined status and cannot check-in."};
                    } else if (serverModel.getBookingList().get(i).getStatus().equals("approved")){
                        index = i;
                        isGood = true;
                        break;
                    }
                }
            }
        } catch (NullPointerException e){
            return new Object[] {null, "Booking not found"};
        }

        if (isGood){
            booking = serverModel.getBookingList().get(index);
            serverModel.getGuestList().add(booking);
            booking.setStatus("checked-in");
            try {
                JSONUtility.saveGuestJSON(serverModel.getGuestList());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return new Object[] {serverModel.getGuestList().get(serverModel.getGuestList().size() - 1), "Checked-in successfully"};
        }
        return new Object[] {null, "Check-in failed"};
    }

    public Object[] checkOutUser(String bookingID, String firstName, String lastName, String phoneNum, String email, String checkInDate, String checkOutDate, String roomType, String roomCapacity, String uniqueID) {
        if (bookingID.isBlank()){
            return new Object[] {null, "Empty bookingID."};
        }

        // Check if fields are empty
        if (firstName.isEmpty() || lastName.isEmpty() || phoneNum.isEmpty() || email.isEmpty() || roomCapacity.isEmpty()) {
            return new Object[] {null, "The fields must not be empty."};
        }

          // Check if fields contains whitespaces or spaces
          if (firstName.isBlank() || lastName.isBlank() || phoneNum.isBlank() || email.isBlank()) {
            return new Object[] {null, "Whitespace or spaces are not allowed."};
        }

        // Check if email format is valid
        if (!email.matches("^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$")) {
            return new Object[] {null, "The email is not valid."};
        }

        //Check if phone number is less than 11 digits
        if (phoneNum.length() < 11) {
            return new Object[] {null, "Phone number should have at least 11 digits.\nIt takes the format '09*********'"};
        }
        //Check if phone number contains non-digits
        if (!phoneNum.matches("\\d+")) {
            return new Object[] {null, "Phone number should contain digits only."};
        }

        for (int i = 0; i < serverModel.getGuestList().size(); i++){
            if (serverModel.getGuestList().get(i).getBookingID().equalsIgnoreCase(bookingID)){
                serverModel.getGuestList().remove(serverModel.getGuestList().get(i));
                break;
            }
        }

        String daysStayed = calculateDaysStayed(checkInDate, checkOutDate);

        // If all checks pass, create a new account
        Booking checkOutBooking = new Booking(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID, daysStayed);

        if (serverModel.getCheckOutList().get(0).getBookingID().equalsIgnoreCase("")){
            serverModel.getCheckOutList().add(checkOutBooking);
            serverModel.getCheckOutList().remove(serverModel.getCheckOutList().get(0));
        } else{
            serverModel.getCheckOutList().add(checkOutBooking);
        }

        try {
            JSONUtility.saveGuestJSON(serverModel.getGuestList());
            JSONUtility.saveCheckOutJSON(serverModel.getCheckOutList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        for (int i = 0; i < serverModel.getRoomsList().size(); i++){
            for (int j = 0; j < serverModel.getBookingList().size(); j++){
                if (serverModel.getBookingList().get(j).getBookingID().equals(bookingID)){
                    serverModel.getBookingList().get(j).setStatus("checked-out");
                    serverModel.getRoomsList().get(i).removeBookedDate(new Object[]{serverModel.getBookingList().get(j).getCheck_in_date(), serverModel.getBookingList().get(j).getCheck_out_date()});
                }
            }
        }
        return new Object[] {checkOutBooking, "Checked out successfully"};
    }
    
    public Object[] logoutAccount(Account account) {
        for (Account entry : serverModel.getAccountList()) {
            if (entry.getAccountNumber().equals(account.getAccountNumber())) {
                entry.setOnline(false);
                System.out.println(entry.getFirstName() + " " + entry.getLastName() + " has logged out.");
                return new Object[]{entry, "Logout successful"};
            }
        }
        return new Object[]{null, "Account not found"};
    }
    
    public Object[] addRooms(String roomType, String roomCapacity, String imgSrc) {
        // Check if roomType is empty or null
        if (roomType == null || roomType.isEmpty()) {
            return new Object[]{null, "Room type cannot be empty."};
        }
        
        // Check if roomCapacity is empty or null
        if (roomCapacity == null || roomCapacity.isEmpty()) {
            return new Object[]{null, "Room capacity cannot be empty."};
        }

        int roomID = serverModel.getRoomsList().size();

        List<Object[]> disabledDates = new ArrayList<>();
        for(Object[] dates: serverModel.getRoomsList().get(0).getDisabledDates()){
            disabledDates.add(dates);
        }

        // // If all validations pass, create a new Room object
        Room newRoom = new Room(roomID+1, roomType, roomCapacity, imgSrc, disabledDates);
        serverModel.getRoomsList().add(newRoom);
    
        return new Object[]{newRoom, "Room added successfully"};
    }

    
    private String calculateDaysStayed(String checkInDate, String checkOutDate) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            LocalDate startDate = LocalDate.parse(checkInDate, formatter);
            LocalDate endDate = LocalDate.parse(checkOutDate, formatter);
            long daysStayed = ChronoUnit.DAYS.between(startDate, endDate);
            return String.valueOf(daysStayed);
        } catch (Exception e) {
            e.printStackTrace();
            return "N/A";
        }
    } // end of calculateDaysStayed

} // end of AuthenticationModel
