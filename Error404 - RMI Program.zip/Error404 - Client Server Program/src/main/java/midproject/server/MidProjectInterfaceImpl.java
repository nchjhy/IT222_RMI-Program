package midproject.server;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import midproject.shared.*;
import midproject.server.model.ServerModel;
import midproject.server.model.AuthenticationModel;
import midproject.utilities.JSONUtility;

public class MidProjectInterfaceImpl extends UnicastRemoteObject implements MidProjectInterface {
    private AuthenticationModel authenticationModel;
    private ServerModel model;
    private List<DataRefreshCallback> callbacks;

    public MidProjectInterfaceImpl(AuthenticationModel authenticationModel, ServerModel model) throws RemoteException {
        super();
        this.authenticationModel = authenticationModel;
        this.model = model;
        this.callbacks = new ArrayList<>();
    }

    @Override
    public synchronized Object[] fetchData() {
        return new Object[]{"REQUESTED_DATA", new Object[] {model.getAccountList(), model.getBookingList(), model.getCheckOutList(), model.getGuestList(), model.getRoomsList()}};
    }

    @Override
    public synchronized Object[] fetchAnnouncements(Date loginTime) {
        List<Announcement> list = new ArrayList<>();
        if (model.getAnnouncements() != null){
            for (Announcement announcement : model.getAnnouncements()){
                if (loginTime.compareTo(announcement.getDate()) < 0){
                    list.add(announcement);
                }
            }
            return new Object[]{"REQUESTED_ANNOUNCEMENTS", list};
        } else {
            System.out.println("No announcements");
        }
        return new Object[]{"REQUESTED_ANNOUNCEMENTS", null};
    }

    @Override
    public synchronized Object[] login(String email, String password) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: LOGIN_REQUEST");

        Object[] result = authenticationModel.authenticate(email, password);
        Account account = (Account) result[0];
        String response = (String) result[1];
        if (account != null) {
            return new Object[]{"LOGIN_SUCCESSFUL", new Object[] {account, response}};
        } else {
            return new Object[]{"LOGIN_FAILED", response};
        }
    }

    public synchronized Object[] logout(Account account) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: LOGOUT_REQUEST");

        Object[] entry = authenticationModel.logoutAccount(account);
        Account acct = (Account) entry[0];
        String message = (String) entry[1];

        return new Object[]{"LOGOUT", acct.getFirstName() + " " + acct.getLastName() + " has logged out"};
    }

    @Override
    public synchronized Object[] announce(String account, String s) throws RemoteException {
        Date date = new Date();
        Announcement newAnnouncement = new Announcement(account, s, date);
        model.getAnnouncements().add(newAnnouncement);
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: ANNOUNCEMENT");
        return new Object[]{"ANNOUNCEMENT", newAnnouncement};
    }

    @Override
    public synchronized Object[] register(String firstName, String lastName, String age, String phoneNum, String email, String password, String confirmPass, String uniqueID) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: REGISTER_REQUEST");
        String accNum = model.getCurrentAccountNumber();

        Object[] credential = authenticationModel.registerUser(accNum, firstName, lastName, age, phoneNum, email, password, confirmPass, uniqueID);
        Account account = (Account) credential[0];
        String response = (String) credential[1];

        // Check if registration was successful
        if (account != null) {
            return new Object[]{"REGISTRATION_SUCCESSFUL",new Object[]{account, response}}; // Registration successful
        } else {
            return new Object[]{"REGISTRATION_FAILED", response}; // Registration failed
        }
    }

    @Override
    // Interface Implementation
    public synchronized Object[] booking(String firstName, String lastName, String phoneNum, String email, String checkInDate, String checkOutDate, String roomType, String roomCapacity, String uniqueID) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: BOOKING_REQUEST");
        String bookingID = model.getCurrentBookingID();

        Object[] bookingInfo = authenticationModel.validateBooking(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID);
        Booking booking = (Booking) bookingInfo[0];
        String response = (String) bookingInfo[1];

        if (response.equals("Successfully booked")) {
            return new Object[]{"BOOKING_SUCCESSFUL", new Object[] {booking, "Your BookingID is " + booking.getBookingID() + ". You can check this in the Booking History. Your status is currently pending. Please wait for booking approval."}}; // Booking successful
        } else {
            return new Object[]{"BOOKING_FAILED", response}; // Booking failed
        }

    }

    @Override
    public synchronized Object[] cancelBooking(String bookingID) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: CANCEL_BOOKING_REQUEST");

        Object[] cBooking = authenticationModel.validateCancelBooking(bookingID);
        int cancelBooking = (int) cBooking[0];
        String response = (String) cBooking[1];

        if(response.equals("Cancelled the booking successfully")) {
            return new Object[]{"CANCEL_BOOKING_SUCCESSFUL", new Object[] {cancelBooking, response}}; // Cancel Booking successful
        } else {
            return new Object[]{"CANCEL_BOOKING_FAILED", response}; // Cancel Booking failed
        }
    }

    @Override
    public synchronized Object[] checkout(String bookingID, String firstName, String lastName, String phoneNum, String email, String checkInDate, String checkOutDate, String roomType, String roomCapacity, String uniqueID) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: CHECKOUT_REQUEST");

        Object[] coBooking = authenticationModel.checkOutUser(bookingID, firstName, lastName, phoneNum, email, checkInDate, checkOutDate, roomType, roomCapacity, uniqueID);
        Booking checkOutBooking = (Booking) coBooking[0];
        String response = (String) coBooking[1];

        if(checkOutBooking != null) {
            return new Object[]{"CHECKOUT_SUCCESSFUL", new Object[] {checkOutBooking, response}}; // Check out successful
        } else {
            return new Object[]{"CHECKOUT_FAILED", response}; // Check out failed
        }

    }

    @Override
    public synchronized Object[] checkin(String bookingID) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: CHECKIN_REQUEST");

        Object[] checkin = authenticationModel.validateCheckIn(bookingID);
        Booking checkIn = (Booking) checkin[0];
        String response = (String) checkin[1];

        if(response.equals("Checked-in successfully")) {
            return new Object[]{"CHECKIN_SUCCESSFUL", new Object[] {checkIn, response}}; // Check in  successful
        } else {
            return new Object[]{"CHECKIN_FAILED", response}; // Check infailed
        }

    }

    @Override
    public Object[] addRoom (String roomType, String roomCapacity, String imgSrc) throws RemoteException {
        System.out.println("\nServer received request from client");
        System.out.println("Request Code: ADD_ROOM_REQUEST");

        Object[] addRoom= authenticationModel.addRooms(roomType, roomCapacity, imgSrc);
        Room rooms = (Room) addRoom[0];
        String response = (String) addRoom[1];

        if(response.equals("Room added successfully")) {
            return new Object[]{"ADD_ROOM_SUCCESSFUL", new Object[] {rooms, response}}; // Add room successful
        } else {
            return new Object[]{"ADD_ROOM_FAILED", response}; // Add room failed
        }

    }

    @Override
    public Object[] disableDates(String start, String end, String reason) throws RemoteException {
        for (int i = 0; i < model.getRoomsList().size(); i++){
            model.getRoomsList().get(i).addDisabledDates(new Object[]{start, end});
        }
        return new Object[]{"DISABLED_DATES", "All rooms are unavailable on " + start + " - " + end + ". - by Management \nReason: " + reason + "."};
    }


    @Override
    public void registerCallback(DataRefreshCallback callback) {
        callbacks.add(callback);
    }

    @Override
    public Object[] ban(int selectedRow) throws RemoteException {
        model.getAccountList().get(selectedRow).setBanned(true);
        try {
            JSONUtility.saveAccountJSON(model.getAccountList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"BAN_SUCCESSFUL", selectedRow};
    }

    @Override
    public Object[] unban(int selectedRow) throws RemoteException {
        model.getAccountList().get(selectedRow).setBanned(false);
        try {
            JSONUtility.saveAccountJSON(model.getAccountList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"UNBAN_SUCCESSFUL", selectedRow};
    }

    @Override
    public Object[] delete(int selectedRow) throws RemoteException {
        model.getAccountList().remove(model.getAccountList().get(selectedRow));
        try {
            JSONUtility.saveAccountJSON(model.getAccountList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"DELETE_SUCCESSFUL", selectedRow};
    }

    @Override
    public Object[] approve(int selectedRow) throws RemoteException {
        int index = 0;
        for (int i = 0; i < model.getBookingList().size(); i++){
            if (model.getBookingList().get(i).getStatus().equals("pending")){
                if(index == selectedRow){
                    index = i;

                    for (int j = 0; j < model.getRoomsList().size(); j++){
                        if (model.getBookingList().get(index).getRoomType().equals(model.getRoomsList().get(j).getRoomType())){
                            model.getRoomsList().get(j).addBookedDate(new Object[]{model.getBookingList().get(index).getCheck_in_date(), model.getBookingList().get(index).getCheck_out_date()});
                        }
                    }
                    break;
                } else {
                    index += 1;
                }
            }
        }

        model.getBookingList().get(index).setStatus("approved");

        for (int i = 0; i < model.getBookingList().size(); i++){
            if (model.getBookingList().get(i).getStatus().equals("pending")){
                if (model.getBookingList().get(i).getCheck_in_date().equals(model.getBookingList().get(index).getCheck_in_date())){
                    model.getBookingList().get(i).setStatus("declined");
                }
            }
        }

        try {
            JSONUtility.saveBookingJSON(model.getBookingList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"APPROVED", index};
    }

    @Override
    public Object[] decline(int selectedRow) throws RemoteException {
        int index = 0;
        for (int i = 0; i < model.getBookingList().size(); i++){
            if (model.getBookingList().get(i).getStatus().equals("pending")){
                if(index == selectedRow){
                    index = i;
                    break;
                } else {
                    index += 1;
                }
            }
        }

        model.getBookingList().get(index).setStatus("declined");
        try {
            JSONUtility.saveBookingJSON(model.getBookingList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"DECLINED", index};
    }

    @Override
    public Object[] editByClient(int selectedRow) throws RemoteException {
        try {
            JSONUtility.saveBookingJSON(model.getBookingList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"APPROVED", selectedRow};
    }

    @Override
    public Object[] editByAdmin(int selectedRow) throws RemoteException {
        try {
            JSONUtility.saveBookingJSON(model.getBookingList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return new Object[]{"APPROVED", selectedRow};
    }
} // end of MidProjectInterfaceImpl class 
