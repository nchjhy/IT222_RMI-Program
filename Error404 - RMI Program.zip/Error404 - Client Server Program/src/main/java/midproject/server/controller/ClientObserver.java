package midproject.server.controller;

public interface ClientObserver {
    void onDataChanged();
} // end of ClientObserver
