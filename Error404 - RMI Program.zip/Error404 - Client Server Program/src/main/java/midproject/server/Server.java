package midproject.server;

import midproject.server.model.AuthenticationModel;
import midproject.server.model.ServerModel;
import midproject.shared.Account;
import midproject.shared.MidProjectInterface;
import midproject.utilities.JSONUtility;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Server {
    private ServerModel serverModel;
    private static final int RMI_PORT = 1099;

    public void run(){
        try {
            InetAddress localhost = InetAddress.getLocalHost();
            String serverIP = localhost.getHostAddress();
            System.out.println("Server IP Address: " + serverIP);

            System.out.println("Starting RMI server...");
            Registry registry = LocateRegistry.createRegistry(RMI_PORT);
            serverModel = new ServerModel();
            AuthenticationModel authenticationModel = new AuthenticationModel(serverModel);
            MidProjectInterface midProjectServerImplementation = new MidProjectInterfaceImpl(authenticationModel, serverModel);
            // Bind the serverController to the RMI registry
            registry.rebind("MidProjectRMI", midProjectServerImplementation);
            System.out.println("RMI server started successfully");

            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                System.out.println("Shutting down server...");
                shutdown();
            }));
        } catch (RemoteException e) {
            System.err.println("Error starting RMI server: " + e.getMessage());
            e.printStackTrace();
        } catch (UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }
    public static void main(String[] args) {
        Server server = new Server();
        server.run();
    }

    private void shutdown() {
        System.out.println("Saving data to JSON files...");

        //set all accounts offline
        for (Account account : serverModel.getAccountList()){
            account.setOnline(false);
        }

        // save any changes to the XML file
        try {
            JSONUtility.saveAccountJSON(serverModel.getAccountList());
            JSONUtility.saveBookingJSON(serverModel.getBookingList());
            JSONUtility.saveCheckOutJSON(serverModel.getCheckOutList());
            JSONUtility.saveGuestJSON(serverModel.getGuestList());
            JSONUtility.saveRoomsJSON(serverModel.getRoomsList());
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    } // end of shutdown
} // end of Server class
